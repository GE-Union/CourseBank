from bingo_card import BingoCard

tests = [
    (
        [("match", 27), ("match", 53), ("match", 73), ("unmatched",), ("match", 15), ("unmatched",), ("reset",), ("unmatched",)],
        [True, False, True, True, True, False, None, True],
        [15, 27, 73]
    ),
    (
        [("match", 11), ("match", 26), ("unmatched",), ("match", 13), ("unmatched",), ("reset",), ("unmatched",)],
        [True, True, False, False, False, None, True],
        [11, 26]
    ),
    (
        [("match", 8), ("match", 14), ("match", 22), ("match", 16), ("match", 20), ("match", 24)],
        [False, True, False, True, False, True],
        [14, 16, 24, 26]
    ),
    (
        [("match", 8), ("unmatched",), ("match", 28), ("unmatched",), ("match", 16), ("unmatched",)],
        [False, True, True, False, False, False],
        [28]
    ),
    (
        [("match", 11), ("match", 15), ("match", 17), ("match", 2), ("unmatched",), ("reset",), ("unmatched",)],
        [True, True, True, False, False, None, True],
        [11, 15, 17]
    ),
    (
        [("match", 27), ("match", 14), ("match", 73), ("unmatched",), ("match", 18), ("unmatched",), ("reset",), ("unmatched",)],
        [False, True, False, True, True, False, None, True],
        [14, 18]
    ),
    (
        [("match", 14), ("match", 21), ("unmatched",), ("match", 28), ("unmatched",), ("reset",), ("unmatched",)],
        [True, True, True, True, False, None, True],
        [14, 21, 28]
    ),
    (
        [("match", 2), ("match", 3), ("match", 16), ("match", 15), ("match", 22), ("match", 21)],
        [False, True, False, True, False, True],
        [3, 9, 15, 21]
    ),
    (
        [("match", 18), ("unmatched",), ("match", 38), ("unmatched",), ("match", 2), ("unmatched",)],
        [False, True, False, True, True, False],
        [2]
    ),
    (
        [("match", 7), ("match", 23), ("match", 14), ("match", 16), ("unmatched",), ("reset",), ("unmatched",)],
        [True, True, True, True, False, None, True],
        [7, 14, 16, 23]
    ),
]


def test():
    SCORE = 0
    for i, (actions, expected, numbers) in enumerate(tests):
        card = BingoCard(numbers)
        results = []
        for action in actions:
            if action[0] == "match":
                results.append(card.match(action[1]))
            elif action[0] == "unmatched":
                results.append(card.unmatched())
            elif action[0] == "reset":
                card.reset()
                results.append(None)
        returned = tuple(results)

        print(f"Test {i+1}: ", end="")
        if returned == tuple(expected):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Actions: {actions}")
            print(f"   Expected: {expected}")
            print(f"   Got:      {returned}")

    print(f"\nSCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()