# modified_blackjack.py 
# CC-BY Louis Leblanc, 2025

def modified_blackjack(cards):
    n = 0
    k = 2
    while True:
        if k > len(cards):
            return (-1, -1)
        s = sum(cards[n:k])
        if s == 21:
            return (n, k - n)
        elif s < 21:
            k += 1
        else:
            n += 1
            k = n + 2
