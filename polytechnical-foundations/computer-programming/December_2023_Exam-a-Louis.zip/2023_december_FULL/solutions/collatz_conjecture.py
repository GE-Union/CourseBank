# collatz_conjecture.py 
# CC-BY Louis Leblanc, 2025

def collatz_conjecture(n):
    steps = 0
    while n != 1:
        if n%2 == 0:
            n /= 2
        else:
            n = 3*n+1
        steps += 1
    return steps