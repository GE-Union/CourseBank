// Javascript for the Micrograph Library

// Default values for window features
var vlocation = 'no';
var vmenubar = 'no';
var vresizable = 'yes';
var vstatus = 'no';
var vscrollbars = 'yes';
var vtoolbar = 'no';
var vwidth = 500;
var vheight = 400;
var vleft = 0;
var vtop = 0;
//==========================================================================
// encodeSpaceChars replaces all space chars by '+' chars for use in a URL. The following would be more efficient but
// depends on Javascript 1.2.
// var encoded = string.replace(/\s/g, "+");
function encodeSpaceChars(string) {
    var encoded = '';
    var i = 0;
    var j = string.indexOf(' ');
    while (j != -1) {
        encoded = encoded + string.substring(i, j) + '+';
        i = j + 1;
        j = string.indexOf(' ', i);
    }
    encoded = encoded + string.substring(i, string.length);
    return encoded;
}
//==========================================================================
// makeFeaturesStr assembles and returns a features string
function makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop) {
    return 'location=' + vlocation + ',menubar=' + vmenubar + ',resizable=' + vresizable + ',status=' + vstatus + ',scrollbars=' + vscrollbars + ',toolbar=' + vtoolbar + ',width=' + vwidth + ',height=' + vheight;
}
//==========================================================================
// openGlossWin opens a new window displaying a MATTER or DoITPoMS Glossary entry
function openGlossWin(term) {
    var vwidth = 700;
    var vheight = 500;
    if (arguments.length > 1) {
        vwidth = arguments[1];
        vheight = arguments[2];
    }
// Following line requires JavaScript 1.2, so replaced by call to function which does same job. DH 21/11/02.
//	var encodedTerm = term.replace(/\s/g, "+");
    var encodedTerm = encodeSpaceChars(term);
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    var win = window.open('/glossary/entry.php?term=' + encodedTerm, '', features);
}
//==========================================================================
// openPopUpWin opens a new window displaying the URL specified in it
function openPopUpWin(url) {
    var vwidth = 700;
    var vheight = 500;
    if (arguments.length > 1) {
        vwidth = arguments[1];
        vheight = arguments[2];
    }
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    var win = window.open(url, '', features);
}
//==========================================================================
// openImgWin opens a new window displaying the image specified by the URL in it
function openImgWin(image, w, h) {
    var vwidth = w + 40;
    var vheight = h + 40;
    var vmenubar = 'yes';
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    var win = window.open('images/' + image, '', features);
}
//==========================================================================
// clearSearchForm clears the contents of the search form
function clearSearchForm(f) {
    f.q.value = '';
    f.f.selectedIndex = 0;
    f.p.checked = false;
    f.c.checked = false;
    f.m.selectedIndex = 0;
    f.b1[0].click();
    f.q2.value = '';
    f.f2.selectedIndex = 0;
    f.p2.checked = false;
    f.c2.checked = false;
    f.m2.selectedIndex = 0;
    f.b2[0].click();
    f.q3.value = '';
    f.f3.selectedIndex = 0;
    f.p3.checked = false;
    f.c3.checked = false;
    f.m3.selectedIndex = 0;
    f.q.focus();
}
//==========================================================================
// openAnswerWin opens a new window displaying the answer or hint for a question
function openAnswerWin(button) {
    var vwidth = 600;
    var vheight = 400;
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    // get question number and type
    var question = button.form.question.value;
    var type = button.form.type.value;
    if (type == '1') {
        // quick multichoice question
        vwidth = 300;
        vheight = 200;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        var response = '';
        for (var i = 0; i < button.form.response.length; i++) {
            if (button.form.response[i].checked) {
                response = button.form.response[i].value;
            }
        }
        var w = window.open('answer.php?question='+question+'&response='+response,'',features);
    }
    else if (type == '2') {
        // long multichoice question with hint and explanatory answers
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        if (button.value == 'Hint') {
            // Hint button clicked
            var win = window.open('answer.php?question='+question+'&button=hint','',features);
        }
        else {
            // Answer button clicked
            var response = '';
            var radio = button.form.response;
            for (var i = 0; i < radio.length; i++) {
                if (radio[i].checked) {
                    response = radio[i].value;
                }
            }
            var win = window.open('answer.php?question='+question+'&button=answer&response='+response,'',features);
        }
    }
    else if (type == '3') {
        // long question with numerical and worked answers
        vwidth = 600;
        vheight = 400;
        if (button.value == 'Worked answer') {
            vwidth = 700;
            vheight = 500;
        }
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        if (button.value == 'Answer') {
            var w = window.open('answer.php?question='+question+'&button=answer','',features);
        }
        else {
            var win = window.open('answer.php?question='+question+'&button=worked','',features);
        }
    }
    else if (type == '4') {
        // long multichoice question with _no_ hint and explantory answers
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        var response = '';
        var radio = button.form.response;
        for (var i = 0; i < radio.length; i++) {
            if (radio[i].checked) {
                response = radio[i].value;
            }
        }
        var win = window.open('answer.php?question='+question+'&response='+response,'',features);
    }
    else if (type == '5') {
        // long yes/no question displayed with checkboxes, with no hint and explantory answers
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        var response = '';
        var checkArray = button.form.response;
        for (var i = 0; i < checkArray.length; i++) {
            if (checkArray[i].checked) {
                response = response + checkArray[i].value;
            }
        }
        var win = window.open('answer.php?question='+question+'&response='+response,'',features);
    }
    else if (type == '7') {
        // quick multichoice question with hint
        if (button.value == 'Hint') {
            // Hint button clicked
            vwidth = 600;
            vheight = 400;
            features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
            var win = window.open('answer.php?question='+question+'&button=hint','',features);
        }
        else {
            vwidth = 300;
            vheight = 200;
            features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
            var response = '';
            for (var i = 0; i < button.form.response.length; i++) {
                if (button.form.response[i].checked) {
                    response = button.form.response[i].value;
                }
            }
            var w = window.open('answer.php?question='+question+'&button=answer'+'&response='+response,'answerwin',features);
        }
    }
    else if (type == '8') {
        // long question with hint and answer
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        if (button.value == 'Hint') {
            var w = window.open('answer.php?question='+question+'&button=hint','',features);
        }
        else {
            var win = window.open('answer.php?question='+question+'&button=answer','',features);
        }
    }
    else if (type == '9') {
        // long yes/no question displayed with radio button pairs, with no hint and explantory answers
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        var response = '';
        var totRadio = button.form.elements.length - 3;
        for (var i = 0; i < totRadio; i = i + 2) {
            if (button.form.elements[2 + i].checked) {
                response = response + 'y';
            }
            else if (button.form.elements[3 + i].checked) {
                response = response + 'n';
            }
            else {
                response = response + '+';
            }
        }
        var win = window.open('answer.php?question='+question+'&response='+response,'',features);
    }
    else if (type == '10') {
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        // long question with hint and answer and worked answer
        if (button.value == 'Hint') {
            var w = window.open('answer.php?question='+question+'&button=hint','',features);
        }
        else if (button.value == 'Answer') {
            var win = window.open('answer.php?question='+question+'&button=answer','',features);
        }
        else {
            var win = window.open('answer.php?question='+question+'&button=worked','',features);
        }
    }
    else if (type == '11') {
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        // long question with answer
        var win = window.open('answer.php?question='+question+'&button=answer','',features);
    }
    else if (type == '12') {
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        // open ended question with hint
        var win = window.open('answer.php?question='+question+'&button=hint','',features);
    }
    else if (type == '13') {
        // quick question with hint and answer
        vwidth = 600;
        vheight = 400;
        features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
        if (button.value == 'Hint') {
            var w = window.open('answer.php?question='+question+'&button=hint','',features);
        }
        else {
            var win = window.open('answer.php?question='+question+'&button=answer','',features);
        }
    }
}
//==========================================================================
// openMediaWin opens a new window displaying media
function openMediaWin(type, file, caption, w, h) {
    var vwidth = w + 150;
    var vheight = h + 180;
    if (type == 'vr') {
        vheight += 40;
    }
// Following line requires JavaScript 1.2, so replaced by call to function which does same job. DH 21/11/02.
//	var encodedCaption = caption.replace(/\s/g, "+");
    var encodedCaption = escape(caption);
    var queryStr = 'type=' + type + '&file=' + file + '&caption=' + encodedCaption + '&width=' + w + '&height=' + h + '&popup=1';
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    var win = window.open('media.php?' + queryStr, '', features);
}
//==========================================================================
// openImageSeqWin opens a new window displaying imageseq.php, with the image and title passed as parameters to it
function openImageSeqWin(type, image, total, caption, w, h) {
    var vwidth = w + 200;
    var vheight = h + 190;
// Following line requires JavaScript 1.2, so replaced by call to function which does same job. DH 21/11/02.
//	var encodedCaption = caption.replace(/\s/g, "+");
    var encodedCaption = escape(caption);
    var queryStr = 'type=' + type + '&image=' + image + '&total=' + total + '&no=1&caption=' + encodedCaption;
    var features = makeFeaturesStr(vlocation, vmenubar, vresizable, vstatus, vscrollbars, vtoolbar, vwidth, vheight, vleft, vtop);
    var win = window.open('imageseq.php?' + queryStr, '', features);
}
//==========================================================================



//==========================================================================
// Following code contained in two files downloaded from http://www.macromedia.com/devnet/activecontent/articles/devletter.html
// deals with changes to IE handling of Flash content to be introduced in versions from early 2004.
// *************************************************************************
// Start of code copied from AC_Flash.js
// The Shockwave versions of functions have been removed.
// The default codebase version has been changed from 7,0,0,0 to 4,0,0,0 as appropriate for the phase diagrams.
//
// The code below contains functions that run active content. The functions
// assemble an OBJECT/EMBED tag string, and then perform a document.write of
// this string in the calling html document.
//   AC_RunFlContent() - build tags to display Flash content.
//   AC_RunFlContentX() - build XHTML formatted tags to display Flash content.
//
// To call one of these functions, pass all the attributes and values that you would
// otherwise specify for the object, param, and embed tags in the following form:
//   AC_RunFlContent(
//     "attrName1", "attrValue1"
//     "attrName2", "attrValue2"
//     ...
//     "attrNamen", "attrValuen"
//   )
//
// When passing in the src or movie attributes, do not include the file extension.
// Note, these functions use default values for several standard tag attributes,
// including classid, codebase, pluginsPage, and mimeType, depending on the function
// you call. So, you should not pass in values for these attributes. If you require
// an alternate values for these attributes, you'll need to modify the default values
// used in the 'Run' function implementations below. However, you may pass in an
// alternate version for the codebase value, as in AC_RunFlContent("codebase","6,0,0,0",...).
// Note that you should only pass in the version string rather than the full
// codebase URL.
//
// You must include AC_RunActiveContent.js for these functions to work.

function AC_RunFlContent()
{
    // First, look for a "movie" and "src" params, and if either exists, add a ".swf" to the end
    // if it doesn't already have one (this function will only run swf files)
    AC_AddExtension(arguments, "movie", ".swf");
    AC_AddExtension(arguments, "src", ".swf");

    // Build the codebase value. If user passed in a version for the codebase, add the version
    // to the base codebase url. Otherwise, use the default version.
    var codebase = AC_GetCodebase
    (  "http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version="
        , "4,0,0,0", arguments
    );

    AC_GenerateObj
    (  "AC_RunFlContent()", false, "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
        , codebase
        , "http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"
        , "application/x-shockwave-flash", arguments
    );
}

function AC_RunFlContentX()
{
    // First, look for a "movie" and "src" params, and if either exists, add a ".swf" to the end
    // if it doesn't already have one (this function will only run swf files)
    AC_AddExtension(arguments, "movie", ".swf");
    AC_AddExtension(arguments, "src", ".swf");

    // Build the codebase value. If user passed in a version for the codebase, add the version
    // to the base codebase url. Otherwise, use the default version.
    var codebase = AC_GetCodebase
    (  "http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version="
        , "4,0,0,0", arguments
    );

    AC_GenerateObj
    (  "AC_RunFlContentX()", true, "clsid:d27cdb6e-ae6d-11cf-96b8-444553540000"
        , codebase
        , "http://www.macromedia.com/shockwave/download/index.cgi?P1_Prod_Version=ShockwaveFlash"
        , "application/x-shockwave-flash", arguments
    );
}

// End of code copied from AC_Flash.js
// *************************************************************************
// Start of code copied from AC_RunActiveContent.js
//
// Implements AC_GenerateObj() function. This is a generic function used to generate
// object/embed/param tags. It is used by higher level api functions.

/************** LOCALIZABLE GLOBAL VARIABLES ****************/

var MSG_EvenArgs = 'The %s function requires an even number of arguments.'
    + '\nArguments should be in the form "atttributeName","attributeValue",...';
var MSG_SrcRequired = "The %s function requires that a movie src be passed in as one of the arguments.";

/******************** END LOCALIZABLE **********************/

// Finds a parameter with the name paramName, and checks to see if it has the
// passed extension. If it doesn't have it, this function adds the extension.
function AC_AddExtension(args, paramName, extension)
{
    var currArg, paramVal, queryStr, endStr;
    for (var i=0; i < args.length; i=i+2){
        currArg = args[i].toLowerCase();
        if (currArg == paramName.toLowerCase() && args.length > i+1) {
            paramVal = args[i+1];
            queryStr = "";

            // Pull off the query string if it exists.
            var indQueryStr = args[i+1].indexOf('?');
            if (indQueryStr != -1){
                paramVal = args[i+1].substring(0, indQueryStr);
                queryStr = args[i+1].substr(indQueryStr);
            }

            endStr = "";
            if (paramVal.length > extension.length)
                endStr = paramVal.substr(paramVal.length - extension.length);
            if (endStr.toLowerCase() != extension.toLowerCase()) {
                // Extension doesn't exist, add it
                args[i+1] = paramVal + extension + queryStr;
            }
        }
    }
}

// Builds the codebase value to use. If the 'codebase' parameter is found in the args,
// uses its value as the version for the baseURL. If 'codebase' is not found in the args,
// uses the defaultVersion.
function AC_GetCodebase(baseURL, defaultVersion, args)
{
    var codebase = baseURL + defaultVersion;
    for (var i=0; i < args.length; i=i+2) {
        currArg = args[i].toLowerCase();
        if (currArg == "codebase" && args.length > i+1) {
            if (args[i+1].indexOf("http://") == 0) {
                // User passed in a full codebase, so use it.
                codebase = args[i+1];
            }
            else {
                codebase = baseURL + args[i+1];
            }
        }
    }

    return codebase;
}

// Substitutes values for %s in a string.
// Usage: AC_sprintf("The %s function requires %s arguments.","foo()","4");
function AC_sprintf(str){
    for (var i=1; i < arguments.length; i++){
        str = str.replace(/%s/,arguments[i]);
    }
    return str;
}

// Checks that args, the argument list to check, has an even number of
// arguments. Alerts the user if an odd number of arguments is found.
function AC_checkArgs(args,callingFn){
    var retVal = true;
    // If number of arguments isn't even, show a warning and return false.
    if (parseFloat(args.length/2) != parseInt(args.length/2)){
        alert(sprintf(MSG_EvenArgs,callingFn));
        retVal = false;
    }
    return retVal;
}

function AC_GenerateObj(callingFn, useXHTML, classid, codebase, pluginsPage, mimeType, args){

    if (!AC_checkArgs(args,callingFn)){
        return;
    }

    // Initialize variables
    var tagStr = '';
    var currArg = '';
    var closer = (useXHTML) ? '/>' : '>';
    var srcFound = false;
    var embedStr = '<embed';
    var paramStr = '';
    var embedNameAttr = '';
    var objStr = '<object classid="' + classid + '" codebase="' + codebase + '"';

    // Spin through all the argument pairs, assigning attributes and values to the object,
    // param, and embed tags as appropriate.
    for (var i=0; i < args.length; i=i+2){
        currArg = args[i].toLowerCase();

        if (currArg == "src"){
            if (callingFn.indexOf("RunSW") != -1){
                paramStr += '<param name="' + args[i] + '" value="' + args[i+1] + '"' + closer + '\n';
                embedStr += ' ' + args[i] + '="' + args[i+1] + '"';
                srcFound = true;
            }
            else if (!srcFound){
                paramStr += '<param name="movie" value="' + args[i+1] + '"' + closer + '\n';
                embedStr += ' ' + args[i] + '="' + args[i+1] + '"';
                srcFound = true;
            }
        }
        else if (currArg == "movie"){
            if (!srcFound){
                paramStr += '<param name="' + args[i] + '" value="' + args[i+1] + '"' + closer + '\n';
                embedStr += ' src="' + args[i+1] + '"';
                srcFound = true;
            }
        }
        else if (   currArg == "width"
            || currArg == "height"
            || currArg == "align"
            || currArg == "vspace"
            || currArg == "hspace"
            || currArg == "class"
            || currArg == "title"
            || currArg == "accesskey"
            || currArg == "tabindex"){
            objStr += ' ' + args[i] + '="' + args[i+1] + '"';
            embedStr += ' ' + args[i] + '="' + args[i+1] + '"';
        }
        else if (currArg == "id"){
            objStr += ' ' + args[i] + '="' + args[i+1] + '"';
            // Only add the name attribute to the embed tag if a name attribute
            // isn't already there. This is what Dreamweaver does if the user
            // enters a name for a movie in the PI: it adds id to the object
            // tag, and name to the embed tag.
            if (embedNameAttr == "")
                embedNameAttr = ' name="' + args[i+1] + '"';
        }
        else if (currArg == "name"){
            objStr += ' ' + args[i] + '="' + args[i+1] + '"';
            // Replace the current embed tag name attribute with the one passed in.
            embedNameAttr = ' ' + args[i] + '="' + args[i+1] + '"';
        }
        else if (currArg == "codebase"){
            // The codebase parameter has already been handled, so ignore it.
        }
            // This is an attribute we don't know about. Assume that we should add it to the
        // param and embed strings.
        else{
            paramStr += '<param name="' + args[i] + '" value="' + args[i+1] + '"' + closer + '\n';
            embedStr += ' ' + args[i] + '="' + args[i+1] + '"';
        }
    }

    // Tell the user that a movie/src is required, if one was not passed in.
    if (!srcFound){
        alert(AC_sprintf(MSG_SrcRequired,callingFn));
        return;
    }

    if (embedNameAttr)
        embedStr += embedNameAttr;
    if (pluginsPage)
        embedStr += ' pluginspage="' + pluginsPage + '"';
    if (mimeType)
        embedStr += ' type="' + mimeType + '"';

    // Close off the object and embed strings
    objStr += '>\n';
    embedStr += '></embed>\n';

    // Assemble the three tag strings into a single string.
    tagStr = objStr + paramStr + embedStr + "</object>\n";

    document.write(tagStr);
}

// End of code copied from AC_RunActiveContent.js
// *************************************************************************
