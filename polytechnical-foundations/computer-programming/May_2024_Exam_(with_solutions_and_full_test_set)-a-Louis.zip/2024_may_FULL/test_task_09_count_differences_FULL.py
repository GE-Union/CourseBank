from count_differences import count_differences

tests = [
    # Test 1
    ('files/results_A1.txt', 'files/results_A2.txt', 3),
    # Test 2
    ('files/results_B1.txt', 'files/results_B2.txt', 6),
    # Test 3
    ('files/results_C1.txt', 'files/results_C2.txt', -1),
    # Test 4
    ('files/results_D1.txt', 'files/results_D2.txt', 0),
    # Test 5
    ('files/results_E1.txt', 'files/results_E2.txt', 1),
    # Test 6
    ('files/results_F1.txt', 'files/results_F2.txt', 2),
    # Test 7
    ('files/results_G1.txt', 'files/results_G2.txt', 8),
    # Test 8
    ('files/results_H1.txt', 'files/results_H2.txt', -1),
    # Test 9
    ('files/results_I1.txt', 'files/results_I2.txt', 0),
    # Test 10
    ('files/results_J1.txt', 'files/results_J2.txt', 4),
]


def test():
    SCORE = 0
    for i, (file1, file2, expected) in enumerate(tests):
        returned = count_differences(file1, file2)
        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Files: {file1}, {file2}\n   Expected: {expected}\n   Got: {returned}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
