import math
from chamber_pressure import chamber_pressure

tests = [
    ((20.0, 120.0, 105.0, 0.1), 19),
    ((10.0, 100.0, 90.0, 0.2), 10),
    ((50.5, 150.0, 140.0, 0.05), 45),
    ((0.4, 11.5, 9.8, 0.15), 12),
    ((49.5, 140.0, 130.0, 0.1), 21),
    ((9.5, 130.0, 120.0, 0.1), 24),
    ((20.0, 120.0, 110.0, 0.016), 143),
    ((10.8, 100.0, 90.0, 0.11), 19),
    ((5.0, 50.0, 45.0, 0.3), 7),
    ((2.0, 20.0, 18.0, 0.9), 1),
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        result = chamber_pressure(*inputs)
        print(f"Test {i+1}: ", end="")
        if math.isclose(result, expected, rel_tol=1e-9):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    chamber_pressure{inputs}")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
