# special_occurrence.py 
# CC-BY Louis Leblanc, 2025

def special_occurrence(sequence):
    for i in range(len(sequence)-2):
        if sequence[i] == 5:
            if (sequence[i+1]==7 and not sequence[i+2]==7) or (not sequence[i+1]==7 and sequence[i+2]==7):
                return i
    return -1