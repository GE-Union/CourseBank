import math
from running_speed import running_speed

tests = [
    (5.5, (10.90909090909091, 3.0303030303030307)),
    (18.0, (3.333333333333333, 0.9259259259259259)),
    (1.3, (46.153846153846146, 12.82051282051282)),
    (22.5, (2.666666666666667, 0.7407407407407408)),
    (55.264, (1.0856977417486973, 0.30158270604130477)),
    (4.412, (13.599274705349048, 3.777576307041402)),
    (7.3267, (8.189225708709241, 2.2747849190859006)),
    (32.43, (1.8501387604070305, 0.5139274334463974)),
    (4.9, (12.244897959183673, 3.4013605442176864)),
    (2.9, (20.689655172413794, 5.74712643678161)),
]


def test():
    SCORE = 0

    for i, (val, expected) in enumerate(tests):
        result = running_speed(val)
        print(f"Test {i+1}: ", end="")
        if math.isclose(result[0], expected[0]) and math.isclose(result[1], expected[1]):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    running_speed({val})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
