# reservoir_levels.py 
# CC-BY Louis Leblanc, 2025

def reservoir_levels(levels):
    alerts = []
    for i in range(1, len(levels)):
        if levels[i-1]-levels[i] > 150:
            alerts.append(i)
    return alerts