from experiment_numbers import experiment_numbers

tests = [
    (['A-1', 'A-3', 'B-2', 'A-4', 'B-1', 'B-3', 'N-4'],
     {'A': 4, 'B': 3, 'N': 4}),

    (['F-2', 'F-10', 'F-5'],
     {'F': 10}),

    (['A-1', 'B-1', 'C-1'],
     {'A': 1, 'B': 1, 'C': 1}),

    (['X-100', 'X-99', 'X-101'],
     {'X': 101}),

    (['A-1', 'B-2', 'C-3', 'A-2', 'B-3', 'C-1', 'M-10', 'M-9', 'M-11', 'M-8'],
     {'A': 2, 'B': 3, 'C': 3, 'M': 11}),

    (['X-5', 'Y-5', 'Z-5'],
     {'X': 5, 'Y': 5, 'Z': 5}),

    (['A-1', 'A-3', 'A-2', 'A-10'],
     {'A': 10}),

    (['D-1', 'D-2', 'D-3', 'D-4', 'D-100', 'D-5'],
     {'D': 100}),

    (['A-3', 'B-4', 'C-2', 'C-5', 'A-5', 'B-2', 'C-1'],
     {'A': 5, 'B': 4, 'C': 5}),

    ([],
     {})
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        result = experiment_numbers(inputs)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    experiment_numbers({inputs})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()