from fruit_weights import fruit_weights

tests = [
    (
        {'apple': 182, 'banana': 110, 'Orange': 160, 'Banana': 115, 'APPLE': 185, 'Apple': 175, 'lime': 67},
        {'apple': 180, 'banana': 112, 'lime': 67, 'orange': 160}
    ),
    (
        {'mango': 255, 'Mango': 345, 'Orange': 160, 'Banana': 115, 'PEAR': 100},
        {'banana': 115, 'mango': 300, 'orange': 160, 'pear': 100}
    ),
    (
        {'Pear': 115, 'APPLE': 185, 'pear': 100, 'PEAR': 120},
        {'pear': 111, 'apple': 185}
    ),
    ({}, {}),
    ({'lime': 67}, {'lime': 67}),
    (
        {'melon': 1890, 'Melon': 1810, 'MELON': 1860},
        {'melon': 1853}
    ),
    (
        {'Pear': 182, 'kiwi': 110, 'Orange': 160, 'Banana': 115, 'APPLE': 185, 'Apple': 175, 'lime': 67, 'mango': 255},
        {'apple': 180, 'banana': 115, 'kiwi': 110, 'lime': 67, 'mango': 255, 'orange': 160, 'pear': 182}
    ),
    (
        {'Banana': 115, 'APPLE': 185, 'Apple': 175, 'lime': 67, 'mango': 255},
        {'apple': 180, 'banana': 115, 'lime': 67, 'mango': 255}
    ),
    (
        {'mango': 245, 'MANGO': 365},
        {'mango': 305}
    ),
    (
        {'grapes': 345, 'GRAPES': 365, 'Grapes': 455, 'plum': 245, 'PLUM': 265, 'Plum': 250},
        {'grapes': 388, 'plum': 253}
    ),
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        result = fruit_weights(inputs)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    fruit_weights({inputs})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
