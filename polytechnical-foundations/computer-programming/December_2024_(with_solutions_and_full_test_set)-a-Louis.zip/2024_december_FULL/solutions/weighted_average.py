# weighted_average.py 
# CC-BY Louis Leblanc, 2025

import numpy as np

def weighted_average(x):
    N = len(x)
    mean = x.sum()/N
    std_dev = np.sqrt(((x - mean)**2).sum()/N)
    if std_dev == 0:
        return mean
    weight = np.exp(-(x - mean)**2/(2*std_dev**2))
    return (weight*x).sum()/weight.sum()