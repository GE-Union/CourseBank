from reservoir_levels import reservoir_levels

tests = [
    ([1320, 1307, 1295, 1102, 1360, 1395, 1101, 1208], [3, 6]),
    ([210, 112, 132, 130, 129, 810, 711, 546, 390, 101, 208, 100], [7, 8, 9]),
    ([1360, 1307, 1360, 1395, 1101, 1208, 1050], [4, 6]),
    ([1350, 1872, 1102, 1360, 1395, 1090, 1208, 1050, 900], [2, 5, 7]),
    ([1109, 1120, 1295, 1232, 1360, 1395, 1301, 1208, 1250, 1630], []),
    ([1320, 1307, 1256, 1208, 1050, 900, 800, 700], [4]),
    ([1307, 1157, 1102, 1360, 1395, 1101, 1208, 1050, 900, 800, 700, 600], [5, 7]),
    ([1000, 1320, 1407, 1295, 1102, 1360, 1395, 1101, 1208, 1050, 900, 800], [4, 7, 9]),
    ([2120, 1607, 1295, 1102, 1360, 1395, 1101, 1208, 1050, 902, 800, 700], [1, 2, 3, 6, 8]),
    ([], []),
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        result = reservoir_levels(inputs)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    reservoir_levels({inputs})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
