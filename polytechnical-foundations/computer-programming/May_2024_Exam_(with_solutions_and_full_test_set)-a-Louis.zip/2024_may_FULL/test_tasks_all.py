from math import floor

import test_task_01_distance_traveled_FULL as t1
import test_task_02_booklet_layout_FULL as t2
import test_task_03_reversed_text_FULL as t3
import test_task_04_first_double_peak_FULL as t4
import test_task_05_robust_values_FULL as t5
import test_task_06_population_convergence_FULL as t6
import test_task_07_event_manager_FULL as t7
import test_task_08_name_frequency_FULL as t8
import test_task_09_count_differences_FULL as t9
import test_task_10_limited_event_manager_FULL as t10


TESTS = (
    ("Distance Travaled", t1),
    ("Booklet Layout", t2),
    ("Reversed Text", t3),
    ("First Double Peak", t4),
    ("Robust Values", t5),
    ("Population Convergence", t6),
    ("Event Manager", t7),
    ("Name Frequency", t8),
    ("Count Differences", t9),
    ("Limited Event Manager", t10)
)


dashes = 60
scores = []
totals = []

for i, (name,task) in enumerate(TESTS):
    print("\n"+"-"*dashes)
    print(f"Task {i}: {name} (Full test suite)")
    print("-"*dashes)
    score,total = task.test()
    scores.append(score)
    totals.append(total)
    print("-"*dashes)

print("")
print( "++++++++++++++++++++++++")
print(f"++ Your score is {floor(sum(scores)/sum(totals) * 100):>3}% ++")
if sum(scores) == sum(totals):
    print("++                    ++")
    print("++     WELL DONE!     ++")
elif sum(scores) >= 0.8*sum(totals):
    print("++                    ++")
    print("++     WAY TO GO!     ++")
elif sum(scores) >= 0.5*sum(totals):
    print("++                    ++")
    print("++    ON YOUR WAY!    ++")
elif sum(scores) >= 0.3*sum(totals):
    print("++                    ++")
    print("++   HANG IN THERE!   ++")
elif sum(scores) >= 0.1*sum(totals):
    print("++                    ++")
    print("++   YOU CAN DO IT!   ++")
print( "++++++++++++++++++++++++")
