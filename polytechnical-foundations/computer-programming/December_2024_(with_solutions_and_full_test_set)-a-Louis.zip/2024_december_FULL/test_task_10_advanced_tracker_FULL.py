from simple_tracker import AdvancedTracker

tests = [
    # Test 1
    (
        [('add', 200), ('add', 352), ('add', 252), ('stats',), ('add', 510)],
        (True, False, True, (452, 52), False),
        500, 100
    ),
    # Test 2
    (
        [('add', 500), ('add', 60), ('add', 61), ('add', 508)],
        (True, False, False, True),
        600, 10
    ),
    # Test 3
    (
        [('add', 80), ('add', 90), ('add', -3)],
        (True, False, False),
        85, 20
    ),
    # Test 4
    (
        [('add', 10), ('add', 0), ('add', 20), ('add', 30), ('add', 55)],
        (True, False, True, True, False),
        100, 20
    ),
    # Test 5
    (
        [('add', 100), ('reset',), ('add', 50), ('add', 50), ('stats',)],
        (True, True, True, (100, 0)),
        1020, 100
    ),
    # Test 6
    (
        [('add', 170), ('add', 45), ('add', 174), ('stats',)],
        (True, False, True, (344, 4)),
        250, 50
    ),
    # Test 7
    (
        [('add', 180), ('add', 495), ('add', 185), ('stats',)],
        (True, False, True, (365, 5)),
        2050, 50
    ),
    # Test 8
    (
        [('add', 90), ('add', 140), ('stats',), ('reset',), ('add', 10), ('stats',)],
        (True, False, (90, 0), True, (10, 0)),
        300, 40
    ),
    # Test 9
    (
        [('add', 5), ('add', 20), ('add', 45), ('add', 80), ('add', 125),
         ('add', 180), ('add', 245), ('add', 320), ('add', 405), ('stats',)],
        (True, True, True, True, True, False, False, False, False, (275, 120)),
        500, 50
    ),
    # Test 10
    (
        [('add', 510), ('add', 1200), ('add', 390), ('stats',),
         ('reset',), ('add', 283), ('add', 798), ('add', 340), ('stats',)],
        (True, False, False, (510, 0), True, False, True, (623, 57)),
        813, 100
    ),
]


def test():
    SCORE = 0
    for i, (actions, expected, limit, threshold) in enumerate(tests):
        tracker = AdvancedTracker(limit, threshold)
        results = []

        for action in actions:
            if action[0] == 'add':
                results.append(tracker.add(action[1]))
            elif action[0] == 'stats':
                results.append(tracker.stats())
            elif action[0] == 'reset':
                tracker.reset()

        returned = tuple(results) if len(results) > 1 else results[0]

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Actions: {actions}\n   should return {expected}\n   but got {returned}")

    print("")
    print(f"SCORE: [{SCORE}/{len(tests)}] ")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()

