# orbital_period.py 
# CC-BY Louis Leblanc, 2025

from math import sqrt, pi

def orbital_period(a, M):
    # You have to use a more precise G constant...
    G = 6.67430e-11
    return 2 * pi * sqrt(a**3 / (G * M))