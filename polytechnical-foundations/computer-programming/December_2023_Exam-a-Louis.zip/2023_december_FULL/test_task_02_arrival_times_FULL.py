from arrival_times import arrival_times

tests = [
    (['12:37', '08:10'], 25, ['13:02', '08:35']),
    (['11:10'], 55, ['12:05']),
    (['23:10', '00:00'], 55, ['00:05', '00:55']),
    (['15:58', '16:22', '19:04', '20:01'], 102, ['17:40', '18:04', '20:46', '21:43']),
    (['09:20', '10:00', '10:14', '10:59'], 0, ['09:20', '10:00', '10:14', '10:59']),
    (['23:59', '00:00', '01:01'], 1, ['00:00', '00:01', '01:02']),
    (['09:20', '10:00', '10:14', '10:59'], 43, ['10:03', '10:43', '10:57', '11:42']),
    (['23:50'], 10, ['00:00']),
    (['11:55', '12:12', '12:48', '13:03', '13:12'], 12,
     ['12:07', '12:24', '13:00', '13:15', '13:24']),
    (['13:00', '14:30', '14:55', '15:05'], 90,
     ['14:30', '16:00', '16:25', '16:35']),
]

def test():
    SCORE = 0
    for i in range(len(tests)):
        returned = arrival_times(tests[i][0], tests[i][1])
        print(f"Test {i+1}: ", end="")
        expected = tests[i][2]
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   arrival_times({repr(tests[i][0])}, {repr(tests[i][1])})\n    should return {repr(expected)},\n    but got {repr(returned)}")

    print("")    

    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)

if __name__ == '__main__':
    test()