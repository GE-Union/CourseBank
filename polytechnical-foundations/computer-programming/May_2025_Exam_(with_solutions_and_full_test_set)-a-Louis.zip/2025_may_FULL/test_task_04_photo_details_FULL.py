from photo_details import photo_details

tests = [
    ('20250305_110031.jpg',
     {'day': '05', 'ext': 'jpg', 'month': '03', 'number': '110031', 'year': '2025'}),

    ('19991231_235959.png',
     {'day': '31', 'ext': 'png', 'month': '12', 'number': '235959', 'year': '1999'}),

    ('19891213_1337.jpeg',
     {'day': '13', 'ext': 'jpeg', 'month': '12', 'number': '1337', 'year': '1989'}),

    ('20230414_5529875364.gif',
     {'day': '14', 'ext': 'gif', 'month': '04', 'number': '5529875364', 'year': '2023'}),

    ('20230505_23.bmp',
     {'day': '05', 'ext': 'bmp', 'month': '05', 'number': '23', 'year': '2023'}),

    ('20200205_9582.tiff',
     {'day': '05', 'ext': 'tiff', 'month': '02', 'number': '9582', 'year': '2020'}),

    ('20110930_113258.jpg',
     {'day': '30', 'ext': 'jpg', 'month': '09', 'number': '113258', 'year': '2011'}),

    ('20000101_000000.png',
     {'day': '01', 'ext': 'png', 'month': '01', 'number': '000000', 'year': '2000'}),

    ('20050809_632987.nef',
     {'day': '09', 'ext': 'nef', 'month': '08', 'number': '632987', 'year': '2005'}),

    ('20241026_1.jpg',
     {'day': '26', 'ext': 'jpg', 'month': '10', 'number': '1', 'year': '2024'}),
]


def test():
    SCORE = 0

    for i, (filename, expected) in enumerate(tests):
        result = photo_details(filename)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    photo_details('{filename}')")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()