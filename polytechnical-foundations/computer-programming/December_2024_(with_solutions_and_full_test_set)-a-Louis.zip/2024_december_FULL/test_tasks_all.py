from math import floor

import test_task_01_traffic_operation_FULL as t1
import test_task_02_orbital_period_FULL as t2
import test_task_03_chamber_pressure_FULL as t3
import test_task_04_reservoir_levels_FULL as t4
import test_task_05_new_price_FULL as t5
import test_task_06_fruit_weights_FULL as t6
import test_task_07_weighted_average_FULL as t7
import test_task_08_pattern_count_FULL as t8
import test_task_09_simple_tracker_FULL as t9
import test_task_10_advanced_tracker_FULL as t10


TESTS = (
    ("Traffic Operation", t1),
    ("Orbital Period", t2),
    ("Chamber Pressure", t3),
    ("Reservoir Levels", t4),
    ("New Price", t5),
    ("Fruit Weights", t6),
    ("Weighted Average", t7),
    ("Pattern Count", t8),
    ("Simple Tracker", t9),
    ("Advanced Tracker", t10)
)


dashes = 60
scores = []
totals = []

for i, (name,task) in enumerate(TESTS):
    print("\n"+"-"*dashes)
    print(f"Task {i}: {name} (Full test suite)")
    print("-"*dashes)
    score,total = task.test()
    scores.append(score)
    totals.append(total)
    print("-"*dashes)

print("")
print( "++++++++++++++++++++++++")
print(f"++ Your score is {floor(sum(scores)/sum(totals) * 100):>3}% ++")
if sum(scores) == sum(totals):
    print("++                    ++")
    print("++     WELL DONE!     ++")
elif sum(scores) >= 0.8*sum(totals):
    print("++                    ++")
    print("++     WAY TO GO!     ++")
elif sum(scores) >= 0.5*sum(totals):
    print("++                    ++")
    print("++    ON YOUR WAY!    ++")
elif sum(scores) >= 0.3*sum(totals):
    print("++                    ++")
    print("++   HANG IN THERE!   ++")
elif sum(scores) >= 0.1*sum(totals):
    print("++                    ++")
    print("++   YOU CAN DO IT!   ++")
print( "++++++++++++++++++++++++")