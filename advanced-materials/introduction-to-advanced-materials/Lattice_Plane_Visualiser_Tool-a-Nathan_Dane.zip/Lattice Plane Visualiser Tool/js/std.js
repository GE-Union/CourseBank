$(function(){
    // Print page link
    $('.tpl-print-link').click(function(e){
        e.preventDefault();

        window.print();
    });

    $('.closeWindow').click(function(e){
        e.preventDefault();

        window.close();
    });

    $('.doitpoms-tlplib-toggle-tags').click(function(e){
        e.preventDefault();

        if ($('#filters').hasClass('d-none')) {
            $('#filters').removeClass('d-none');
        }
        else {
            $('#filters').addClass('d-none');
        }
    });

    $('.doitpoms-tlplib-toggle-descriptions').click(function(e){
        e.preventDefault();

        $('.doitpoms-tlplib-tlp > .card-body > .card-text').toggle();
    });

    // Enable BS tooltips everywhere
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    })
});
