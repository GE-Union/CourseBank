from math import floor

import test_task_01_event_probability_FULL as t1
import test_task_02_arrival_times_FULL as t2
import test_task_03_special_occurrence_FULL as t3
import test_task_04_punctuation_ratio_FULL as t4
import test_task_05_checkerboard_sum_FULL as t5
import test_task_06_collatz_conjecture_FULL as t6
import test_task_07_bank_account_FULL as t7
import test_task_08_phonebook_merge_FULL as t8
import test_task_09_nitrate_levels_FULL as t9
import test_task_10_overdraft_account_FULL as t10

TESTS = (
    ("Event Probability", t1),
    ("Arrival Times", t2),
    ("Special Occurence", t3),
    ("Punctuation Ratio", t4),
    ("Checkboard Sum", t5),
    ("Collatz Conjecture", t6),
    ("Bank Account", t7),
    ("Phonebook Merge", t8),
    ("Nitrate Levels", t9),
    ("Overdraft Account", t10)
)

dashes = 60
scores = []
totals = []

for i, (name,task) in enumerate(TESTS):
    print("\n"+"-"*dashes)
    print(f"Task {i}: {name} (Full test suite)")
    print("-"*dashes)
    score,total = task.test()
    scores.append(score)
    totals.append(total)
    print("-"*dashes)

print("")
print( "++++++++++++++++++++++++")
print(f"++ Your score is {floor(sum(scores)/sum(totals) * 100):>3}% ++")
if sum(scores) == sum(totals):
    print("++                    ++")
    print("++     WELL DONE!     ++")
elif sum(scores) >= 0.8*sum(totals):
    print("++                    ++")
    print("++     WAY TO GO!     ++")
elif sum(scores) >= 0.5*sum(totals):
    print("++                    ++")
    print("++    ON YOUR WAY!    ++")
elif sum(scores) >= 0.3*sum(totals):
    print("++                    ++")
    print("++   HANG IN THERE!   ++")
elif sum(scores) >= 0.1*sum(totals):
    print("++                    ++")
    print("++   YOU CAN DO IT!   ++")
print( "++++++++++++++++++++++++")