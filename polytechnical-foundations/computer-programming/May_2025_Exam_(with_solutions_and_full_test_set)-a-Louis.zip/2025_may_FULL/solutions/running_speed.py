# running_speed.py 
# CC-BY Louis Leblanc, 2025

def running_speed(pace):
    return (60/pace, 1000/(60*pace))