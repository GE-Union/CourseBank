# checkerboard_sum.py 
# CC-BY Louis Leblanc, 2025

def checkerboard_sum(A):
    rows, columns = A.shape
    sum = 0.0

    for i in range(rows):
        for j in range(columns):
            # Feels like a neat way to solve this ✨
            if (i+j)%2 == 0:
                sum += A[i,j]

    return sum