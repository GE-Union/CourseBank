# phonebook_merge.py 
# CC-BY Louis Leblanc, 2025

def phonebook_merge(phonebook, second_phonebook):
    for name in second_phonebook.keys():
        if name not in phonebook.keys():
            phonebook[name] = second_phonebook[name]
        else:
            for number in second_phonebook[name]:
                if number not in phonebook[name]:
                    phonebook[name].append(number)
    return phonebook