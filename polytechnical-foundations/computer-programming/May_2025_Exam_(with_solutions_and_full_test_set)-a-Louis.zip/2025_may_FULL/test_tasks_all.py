from math import floor

import test_task_01_polygon_area_FULL as t1
import test_task_02_modified_blackjack_FULL as t2
import test_task_03_running_speed_FULL as t3
import test_task_04_photo_details_FULL as t4
import test_task_05_experiment_numbers_FULL as t5
import test_task_06_bouncing_ball_FULL as t6
import test_task_07_number_statistics_FULL as t7
import test_task_08_two_means_FULL as t8
import test_task_09_bingo_card_FULL as t9
import test_task_10_informative_bingo_card_FULL as t10


TESTS = (
    ("Polygon Area", t1),
    ("Modified Blackjack", t2),
    ("Running Speed", t3),
    ("Photo Details", t4),
    ("Experiment Numbers", t5),
    ("Number Statistics", t6),
    ("Event Manager", t7),
    ("Two Means", t8),
    ("Bingo Card", t9),
    ("Informative Bingo Card", t10)
)


dashes = 60
scores = []
totals = []

for i, (name,task) in enumerate(TESTS):
    print("\n"+"-"*dashes)
    print(f"Task {i}: {name} (Full test suite)")
    print("-"*dashes)
    score,total = task.test()
    scores.append(score)
    totals.append(total)
    print("-"*dashes)

print("")
print( "++++++++++++++++++++++++")
print(f"++ Your score is {floor(sum(scores)/sum(totals) * 100):>3}% ++")
if sum(scores) == sum(totals):
    print("++                    ++")
    print("++     WELL DONE!     ++")
elif sum(scores) >= 0.8*sum(totals):
    print("++                    ++")
    print("++     WAY TO GO!     ++")
elif sum(scores) >= 0.5*sum(totals):
    print("++                    ++")
    print("++    ON YOUR WAY!    ++")
elif sum(scores) >= 0.3*sum(totals):
    print("++                    ++")
    print("++   HANG IN THERE!   ++")
elif sum(scores) >= 0.1*sum(totals):
    print("++                    ++")
    print("++   YOU CAN DO IT!   ++")
print( "++++++++++++++++++++++++")
