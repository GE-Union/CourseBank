# name_frequency.py 
# CC-BY Louis Leblanc, 2025

def name_frequency(names):
    frequency = {}
    for n in names:
        first_name = n.split()[0]
        if first_name not in frequency.keys():
            frequency[first_name] = 1
        else:
            frequency[first_name] += 1
    return frequency