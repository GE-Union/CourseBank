from name_frequency import name_frequency

tests = [
    # Test 1
    (
        ['Liv Ea Jensen', 'Mads Oliver', 'Steve Madsen', 'Anna Simon', 'Simon Gade', 'Mads Kai Jensen'],
        {'Anna': 1, 'Liv': 1, 'Mads': 2, 'Simon': 1, 'Steve': 1}
    ),
    # Test 2
    (
        ['Anne-Marie Sigurdsen', 'Marie-Anne Jones'],
        {'Anne-Marie': 1, 'Marie-Anne': 1}
    ),
    # Test 3
    (
        ['Liv Ea Jensen', 'Mads Oliver', 'Steve Madsen', 'Anna Simon', 
         'Simon Gade', 'Mads Kai Jensen', 'Liv Anna Jensen', 'Liv Ea Jensen'],
        {'Anna': 1, 'Liv': 3, 'Mads': 2, 'Simon': 1, 'Steve': 1}
    ),
    # Test 4
    (
        [],
        {}
    ),
    # Test 5
    (
        ['Taylor Swift', 'Taylor Lautner'],
        {'Taylor': 2}
    ),
    # Test 6
    (
        ['Liv Larsen', 'Mads Oliver', 'Long John Silver'],
        {'Liv': 1, 'Mads': 1, 'Long': 1}
    ),
    # Test 7
    (
        ['John Michael Doe', 'Michael John Smith'],
        {'John': 1, 'Michael': 1}
    ),
    # Test 8
    (
        ['John Doe', 'John Doe', 'Jane Doe'],
        {'John': 2, 'Jane': 1}
    ),
    # Test 9
    (
        ['John-Thomas Larsen', 'Brane-Marie Jensen', 'John-Thomas Larsen', 'John-Thomas Larsen'],
        {'John-Thomas': 3, 'Brane-Marie': 1}
    ),
    # Test 10
    (
        ['John Paul Jones', 'Paul John Smith', 'John Paul Stevens', 'The Pope'],
        {'John': 2, 'Paul': 1, 'The': 1}
    ),
]


def test():
    SCORE = 0
    for i, (names, expected) in enumerate(tests):
        returned = name_frequency(names)
        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Input: {names}\n   Expected: {expected}\n   Got: {returned}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
