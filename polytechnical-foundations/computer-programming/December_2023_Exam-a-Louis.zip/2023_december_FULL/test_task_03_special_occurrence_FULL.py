from special_occurrence import special_occurrence

tests = [
    ([2, 8, 11, 3, 12, 5, 7, 7, 11, 3, 12, 5, 2, 7, 5, 7, 2, 6], 11),
    ([2, 8, 11, 5, 5, 7, 11, 3, 12, 5, 2, 7, 5, 7, 2, 6], 3),
    ([11, 3, 12, 5, 2, 5, 7, 7, 6, 2, 8, 11, 3, 12, 5, 7, 7, 11, 3, 12, 5, 2, 7, 5, 7, 2, 6], 20),
    ([5, 8, 7, 3, 12, 5, 7, 7, 11, 3, 12, 5, 2, 7, 5, 7, 2, 6], 0),
    ([2, 8, 11, 3, 12, 5, 7, 7, 11, 3, 12, 5, 7, 7, 5, 7, 7, 5], -1),
    ([3, 4, 6, 7, 8, 9, 2, 3, 4, 5, 7, 7, 5], -1),
    ([5, 5, 7], 0),
    ([], -1),
    ([5, 7], -1),
    ([5], -1),
]


def test():
    SCORE = 0
    for i, (input_list, expected) in enumerate(tests, 1):
        returned = special_occurrence(input_list)
        print(f"Test {i}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   special_occurrence({repr(input_list)})\n    should return {repr(expected)},\n    but got {repr(returned)}")

    print(f"\nSCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()