# punctuation_ratio.py 
# CC-BY Louis Leblanc, 2025

def punctuation_ratio(text):
    total_valid_and = 0
    for i in range(len(text)):
        if i < len(text)-5:
            if text[i:i+5] == " and ":
                total_valid_and += 1

    total_comma_and = text.count(", and ")
   
    if total_comma_and == total_valid_and:
        return 0

    ratio = total_comma_and/(total_valid_and - total_comma_and)
    return ratio