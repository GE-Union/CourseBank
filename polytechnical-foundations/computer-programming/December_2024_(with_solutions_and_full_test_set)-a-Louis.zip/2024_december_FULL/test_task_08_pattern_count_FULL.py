import os

from pattern_count import pattern_count

tests = [
    ("files/dna_data_1.txt", "ACCG", 2),
    ("files/dna_data_2.txt", "ATACGACT", 3),
    ("files/dna_data_3.txt", "AAC", 1),
    ("files/dna_data_4.txt", "AATT", 6),
    ("files/dna_data_5.txt", "ACCCA", 7),
    ("files/dna_data_1.txt", "AGGG", 5),
    ("files/dna_data_2.txt", "ACGACGACG", 0),
    ("files/dna_data_3.txt", "CG", 15),
    ("files/dna_data_4.txt", "TGGT", 4),
    ("files/dna_data_5.txt", "TTA", 11),
]

for (filename,_,_) in tests:
    if not os.path.isfile(filename):
        print(f'Test for task 8 failed because file \"{filename}\" could not be found.')
        print('This does not indicate anything about the correctness of your code.')
        print('Please open the correct directory in VSCode (as described under `Solving Exam Tasks` in the pdf), or modify the path above.')
        exit(1)


def test():
    SCORE = 0

    for i, (fname, pattern, expected) in enumerate(tests, start=1):
        print(f"Test {i}: ", end="")
        try:
            result = pattern_count(fname, pattern)
            if result == expected:
                print("Passed")
                SCORE += 1
            else:
                print("Failed")
                print(f"    Expected: {expected}")
                print(f"    Got     : {result}")
        except Exception as e:
            print("Failed with Exception")
            print("    Exception:", e)

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")

    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
