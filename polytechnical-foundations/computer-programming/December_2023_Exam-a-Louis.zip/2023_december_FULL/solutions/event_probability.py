# event_probability.py 
# CC-BY Louis Leblanc, 2025

def event_probability(T,n):
    return 1-(1- 1/T)**n