# event_manager.py 
# CC-BY Louis Leblanc, 2025

class EventManager():
    def __init__(self):
        self.registrations = []

    def register(self, user):
        if user in self.registrations:
            return False
        else:
            self.registrations.append(user)
            return True
    def deregister(self, user):
        if user in self.registrations:
            self.registrations.remove(user)
            return True 
        else:
            return False
    def get_num_registrations(self):
        return len(self.registrations)

class LimitedEventManager(EventManager):
    def __init__(self, registration_limit):
        super().__init__()
        self.registration_limit = registration_limit

    def register(self, user):
        if self.get_num_registrations() < self.registration_limit:
            return super().register(user)
        else:
            return False
