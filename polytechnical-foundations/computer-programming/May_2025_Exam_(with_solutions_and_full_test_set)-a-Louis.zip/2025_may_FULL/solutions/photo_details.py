# photo_details.py 
# CC-BY Louis Leblanc, 2025

def photo_details(filename):
    details = {
        'year': filename[0:4],
        'month': filename[4:6],
        'day': filename[6:8]
    }
    id,ext = filename[9:].split('.')
    details['number'] = id
    details['ext'] = ext
    return details