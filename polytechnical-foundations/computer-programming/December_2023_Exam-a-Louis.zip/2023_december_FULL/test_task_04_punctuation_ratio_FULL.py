import math
from punctuation_ratio import punctuation_ratio


tests = [
    (
        'Sara and Emma like to travel, bike, and hike, and when they are traveling they always '
        'take their bikes, hiking shoes, and sleeping bags. Last year, Sarah and Emma traveled to '
        'Italy, France, and Spain. And that was fun, and, according to Sara and Emma, very expensive!',
        1.3333333333333333
    ),
    (
        'This is some text and not just any text, and more than just text. ',
        1.0
    ),
    (
        'Martin and Emma, and Simon and Mia, and Sara, and Ella are all here.',
        1.5
    ),
    (
        'Text without and.',
        0.0
    ),
    (
        'Text with only one type of and, and with a comma.',
        0.0
    ),
    (
        'Travel, bike, and hike. Travel, bike, and hike. Travel, bike, and hike. '
        'Travel, bike, and hike. Travel, bike, and hike. Now and then. ',
        5.0
    ),
    (
        '',
        0.0
    ),
    (
        'And and and and but, and and and.',
        0.25
    ),
    (
        'This is and one, this is another and, and this is a third and.',
        1.0
    ),
    (
        'Now way, and no way! Why is and a good word? Nobody and knows! '
        'But and is not the end of the world, and an end.',
        0.6666666666666666
    ),
]


def test():
    SCORE = 0
    for i in range(len(tests)):
        returned = punctuation_ratio(tests[i][0])
        expected = tests[i][1]

        print(f"Test {i+1}: ", end="")
        if math.isclose(returned, expected):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   punctuation_ratio({repr(tests[i][0])})\n    should return {repr(expected)}\n    but got {repr(returned)}")

    print("")    

    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")
    
    return SCORE, len(tests)


if __name__ == '__main__':
    test()