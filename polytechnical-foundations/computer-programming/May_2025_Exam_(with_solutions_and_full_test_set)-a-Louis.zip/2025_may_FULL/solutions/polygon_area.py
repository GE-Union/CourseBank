# polygon_area.py 
# CC-BY Louis Leblanc, 2025

from math import tan, pi

def polygon_area(n, s):
    return (n*s**2)/(4*tan(pi/n))