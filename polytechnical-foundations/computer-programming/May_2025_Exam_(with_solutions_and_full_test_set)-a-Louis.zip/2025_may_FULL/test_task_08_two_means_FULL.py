import math
import numpy as np
from two_means import two_means

tests = [
    (np.array([1.5, 8.5, 3.5, 4.5, 5.0, 6.5, 7.5, 2.5, 1.0]), 5.5, (3.0, 7.5)),
    (np.array([25, 29, 4.9, 5.0, 5.1, 5.2, 23, 25]), 13.0, (5.05, 25.5)),
    (np.array([1.1, 2.2, 3.3, 4.4, 5.5]), 3.0, (1.65, 4.4)),
    (np.array([-10.0, 0.0, 10.0]), 0.0, (-10.0, 10.0)),
    (np.array([5.0, 6.0, 5.0, 6.0, 7.0]), 6.0, (5.0, 7.0)),
    (np.array([-1.0, -20.1, -2.2, 3.3, -0.19, -3.0, -2.0]), -2.0, (-8.433333333333334, 0.7033333333333333)),
    (np.array([8.4, 8.4, 8.4]), 8.4, (8.4, 8.4)),
    (np.array([1.0, 2.0, 3.0]), 12.0, (2.0, 12.0)),
    (np.array([6.0, 7.0, 8.0]), 3.2, (3.2, 7.0)),
    (np.array([]), 42.0, (42.0, 42.0)),
]


def test():
    SCORE = 0

    for i, (arr, threshold, expected) in enumerate(tests):
        result = two_means(arr, threshold)
        print(f"Test {i+1}: ", end="")
        if math.isclose(result[0], expected[0]) and math.isclose(result[1], expected[1]):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    two_means({arr}, {threshold})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()