from booklet_layout import booklet_layout

tests = [
    (17, (20, 3)),
    (25, (28, 3)),
    (31, (32, 1)),
    (28, (28, 0)),
    (6, (8, 2)),
    (1, (4, 3)),
    (11, (12, 1)),
    (118, (120, 2)),
    (72, (72, 0)),
    (64, (64, 0))
]


def test():
    SCORE = 0
    for i, (input_val, expected) in enumerate(tests):
        returned = booklet_layout(input_val)

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   booklet_layout({repr(input_val)})\n    should return {repr(expected)}\n    but got {repr(returned)}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
