# distance_traveled.py 
# CC-BY Louis Leblanc, 2025

def distance_traveled(t):
    return (9.81*t**2)/2