import os
from number_statistics import number_statistics

tests = [
    ('files/numbers_1.txt', 8, [1, 0, 2]),
    ('files/numbers_2.txt', 10, [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1]),
    ('files/numbers_3.txt', 4, [1, 0, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 0, 2, 1, 1, 0, 1, 1, 0, 2, 1, 2, 0, 2, 0, 1, 0, 1, 0, 1, 0, 1, 0, 0]),
    ('files/numbers_4.txt', 223, [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0]),
    ('files/numbers_5.txt', 11, [0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0]),
    ('files/numbers_6.txt', 17, [0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1]),
    ('files/numbers_7.txt', 32, [0, 0, 1, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 2]),
    ('files/numbers_8.txt', 80, [0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0]),
    ('files/numbers_7.txt', 68, [0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
    ('files/numbers_6.txt', 23, [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0])
]

for (filename, _, _) in tests:
    if not os.path.isfile(filename):
        print('Test for task 7 failed because filename could not be found.')
        print('This does not indicate anything about the correctness of your code.')
        print('Please open the correct directory in VSCode (as described under `Solving Exam Tasks` in the pdf), or modify the path above.')
        exit(1)


def test():
    SCORE = 0

    for i, (filename, number, expected) in enumerate(tests):
        result = number_statistics(filename, number)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    number_statistics(\"{filename}\", {number})")
            print(f"    Expected: {expected}")
            print(f"    Got:      {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()