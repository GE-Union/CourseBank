# bingo_card.py 
# CC-BY Louis Leblanc, 2025

class BingoCard:
    def __init__(self, numbers):
        self.matches = {}
        for i in numbers:
            self.matches[i] = False
    
    def match(self, number):
        if number in self.matches.keys():
            self.matches[number] = True
            return True
        else:
            return False

    def unmatched(self):
        if False in self.matches.values():
            return True
        return False 

    def reset(self):
        for k in self.matches.keys():
            self.matches[k] = False


class InformativeBingoCard(BingoCard):
    def unmatched(self):
        return list(self.matches.values()).count(False)