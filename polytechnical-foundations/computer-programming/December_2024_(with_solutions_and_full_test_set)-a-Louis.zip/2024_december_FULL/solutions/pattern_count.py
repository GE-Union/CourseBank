# pattern_count.py 
# CC-BY Louis Leblanc, 2025

def pattern_count(filename, pattern):
    strand = ""
    count = 0

    # We join all the lines together 👉👈
    with open(filename, 'r') as f:
        for line in f.readlines():
            strand += line.rstrip('\n')

    # We iterate over every single letter in the strand
    # since we also have to detect overlapping patterns
    for i in range(len(strand)):
        # For each letter in the pattern, we check if 
        # the current strand letter matches. If so, we 
        # check the next one, and so on...
        for j in range(len(pattern)):
            # Overflow check
            if i+j >= len(strand):
                break

            # We check whether the letters match
            if strand[i + j] == pattern[j]:
                # They match! 🔥
                # If it was the last letter of the pattern,
                # we can increase the count and exit the inner loop
                if j == len(pattern)-1:
                    count += 1
                    break
                # If not, we just let the program run
                # through the next iteration of the inner loop
            else:
                # They don't match, so we exit the inner loop 😢
                break

    return count