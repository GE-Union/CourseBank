# two_means.py 
# CC-BY Louis Leblanc, 2025

from numpy import array, mean

def two_means(numbers, threshold):
    low = array([n for n in numbers if n < threshold])
    high = array([n for n in numbers if n > threshold])
    if len(low):
        if len(high):
            return (float(mean(low)),float(mean(high)))
        else:
            return (float(mean(low)),threshold)
    else:
        if len(high):
            return (threshold,float(mean(high)))
        else:
            return (threshold,threshold)