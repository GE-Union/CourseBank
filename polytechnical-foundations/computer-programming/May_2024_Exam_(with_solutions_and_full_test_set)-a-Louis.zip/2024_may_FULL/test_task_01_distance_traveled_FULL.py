import math
from distance_traveled import distance_traveled

tests = [
    (5.5, 148.37625),
    (12.8, 803.6352),
    (0.7, 2.40345),
    (4.2, 86.5242),
    (0.0, 0.0),
    (3.9, 74.60505),
    (1348.0, 8912895.12),
    (0.01, 0.0004905),
    (5.002, 122.72311962),
    (1.778, 15.50609802)
]


def test():
    SCORE = 0
    for i, (input_val, expected) in enumerate(tests):
        returned = distance_traveled(input_val)

        print(f"Test {i+1}: ", end="")
        if math.isclose(returned, expected, rel_tol=1e-9):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   distance_traveled({repr(input_val)})\n    should return {repr(expected)}\n    but got {repr(returned)}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
