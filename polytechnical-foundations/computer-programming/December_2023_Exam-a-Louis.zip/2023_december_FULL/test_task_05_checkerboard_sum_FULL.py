import math
import numpy as np
from checkerboard_sum import checkerboard_sum

tests = [
    (
        np.array([[1.42, 4.0, 55.56, 63.0],
                  [2.22, 2.22, 33.73, 40.11],
                  [12.1, 17.24, 18.0, 33.5],
                  [21.15, 14.76, 17.3, 22.1],
                  [5.34, 6.0, 9.8, 8.18]]),
        181.41
    ),
    (
        np.array([[10.42, 4.0]]),
        10.42
    ),
    (
        np.array([[10.42, 4.0, 15.06]]),
        25.48
    ),
    (
        np.array([[1.42], [0.22], [17.1], [13.15], [25.34]]),
        43.86
    ),
    (
        np.array([[0.46003339, 0.36912248],
                  [0.01505454, 0.99462051]]),
        1.4546539
    ),
    (
        np.zeros((50, 60)),
        0.0
    ),
    (
        6 * np.ones((50, 60)),
        9000.0
    ),
    (
        np.array([[18.0]]),
        18.0
    ),
    (
        7 * np.eye(5),
        35.0
    ),
    (
        np.array([[]]),
        0.0
    ),
]


def test():
    SCORE = 0
    for i in range(len(tests)):
        returned = checkerboard_sum(tests[i][0])
        expected = tests[i][1]

        print(f"Test {i+1}: ", end="")
        if math.isclose(returned, expected, rel_tol=1e-9):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   checkerboard_sum({repr(tests[i][0])})\n    should return {repr(expected)}\n    but got {repr(returned)}")

    print("")    
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()