from traffic_operation import traffic_operation

tests = [
    (8, 'rush hour'),
    (5, 'night'),
    (7, 'rush hour'),
    (9, 'normal'),
    (14, 'normal'),
    (16, 'rush hour'),
    (21, 'normal'),
    (23, 'night'),
    (0, 'night'),
    (6, 'normal')
]

def test():
    SCORE = 0
    for i, (inp, expected) in enumerate(tests):
        result = traffic_operation(inp)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    traffic_operation({inp})")
            print(f"    Expected '{expected}', got '{result}'")

    print("")
    print(f"SCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
