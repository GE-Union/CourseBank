# first_double_peak.py 
# CC-BY Louis Leblanc, 2025

def first_double_peak(sequence):
    for i in range(len(sequence) - 4):
        if (
            sequence[i] < sequence[i + 2]
            and sequence[i + 1] < sequence[i + 2]
            and sequence[i + 3] < sequence[i + 2]
            and sequence[i + 4] < sequence[i + 2]
        ):
            return i + 2
    return -1