# robust_values.py 
# CC-BY Louis Leblanc, 2025

import numpy as np

def robust_values(x):
    mean = x.mean()
    std = x.std()
    array = []
    for value in x:
        if mean - std <= value <= mean + std:
            array.append(value)
    return np.array(array)