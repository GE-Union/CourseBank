from polygon_area import polygon_area

tests = [
    ((5, 4.31), 31.9597602410807),
    ((3, 2.5), 2.7063293868263716),
    ((4, 17.5), 306.25000000000006),
    ((6, 3.5), 31.82643358907812),
    ((7, 2.5), 22.711952775009934),
    ((8, 1.5), 10.863961030678928),
    ((9, 1.0), 6.181824193772901),
    ((10, 0.5), 1.9235522107345335),
    ((11, 0.1), 0.09365639906945439),
    ((12, 0.05), 0.027990381056766586),
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        n, side = inputs
        result = polygon_area(n, side)

        print(f"Test {i+1}: ", end="")
        if abs(result - expected) < 1e-9:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    polygon_area({n}, {side})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
