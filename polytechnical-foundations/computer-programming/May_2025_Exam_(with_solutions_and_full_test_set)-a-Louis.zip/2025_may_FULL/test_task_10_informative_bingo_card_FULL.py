from bingo_card import InformativeBingoCard

tests = [
    # Test 1
    (
        [("match", 27), ("match", 53), ("match", 73), ("unmatched",), 
         ("match", 15), ("unmatched",), ("reset",), ("unmatched",)],
        (True, False, True, 1, True, 0, 3),
        [15, 27, 73]
    ),
    # Test 2
    (
        [("match", 11), ("match", 26), ("unmatched",), ("match", 13), 
         ("unmatched",), ("reset",), ("unmatched",)],
        (True, True, 0, 0, False, 2),
        [11, 26]
    ),
    # Test 3
    (
        [("match", 8), ("unmatched",), ("match", 28), ("unmatched",), 
         ("match", 16), ("unmatched",)],
        (False, 1, True, 0, False, 0),
        [28]
    ),
    # Test 4
    (
        [("match", 27), ("match", 14), ("match", 73), ("unmatched",), 
         ("match", 18), ("unmatched",), ("reset",), ("unmatched",)],
        (False, True, False, 1, True, 0, 2),
        [14, 18]
    ),
    # Test 5
    (
        [("match", 14), ("match", 21), ("unmatched",), ("match", 28), 
         ("unmatched",), ("reset",), ("unmatched",)],
        (True, True, 1, True, 0, 3),
        [14, 21, 28]
    ),
    # Test 6
    (
        [("match", 18), ("unmatched",), ("match", 38), ("unmatched",), 
         ("match", 2), ("unmatched",)],
        (False, 1, False, 1, True, 0),
        [2]
    ),
    # Test 7
    (
        [("unmatched",), ("match", 8), ("unmatched",), ("match", 22), 
         ("unmatched",), ("match", 16), ("unmatched",), ("match", 10), 
         ("unmatched",), ("match", 7), ("unmatched",), ("match", 18), 
         ("unmatched",)],
        (7, False, 7, True, 6, True, 5, False, 5, False, 5, True, 4),
        [12, 14, 16, 18, 20, 22, 24]
    ),
    # Test 8
    (
        [("unmatched",), ("match", 8), ("unmatched",), ("match", 15), 
         ("unmatched",), ("match", 25), ("unmatched",), ("reset",), 
         ("unmatched",), ("match", 15), ("unmatched",), ("match", 8), 
         ("unmatched",)],
        (6, False, 6, True, 5, True, 4, 6, True, 5, False, 5),
        [13, 15, 17, 23, 25, 29]
    ),
    # Test 9
    (
        [("match", n) for n in range(4, 100, 5)] + 
        [("unmatched",) for _ in range(20)],
        tuple([True]*20 + list(range(19, -1, -1))),
        list(range(4, 100, 5))
    ),
    # Test 10
    (
        [("unmatched",), ("match", 88), ("unmatched",), ("match", 50), 
         ("unmatched",), ("match", 75), ("unmatched",), ("reset",), 
         ("unmatched",), ("match", 80), ("unmatched",), ("match", 90), 
         ("unmatched",)],
        (9, False, 9, True, 8, False, 8, 9, True, 8, True, 7),
        list(range(10, 100, 10))
    ),
]


def test():
    SCORE = 0
    for i, (actions, expected, numbers) in enumerate(tests):
        if i == 8:
            nrs = list(range(4, 100, 5))
            card = InformativeBingoCard(nrs)
            vals_true = []
            vals_decreasing = []
            for n in nrs:
                vals_true.append(card.match(n))
                vals_decreasing.append(card.unmatched())
            returned = tuple(vals_true + vals_decreasing)
        else:
            card = InformativeBingoCard(numbers)
            results = []
            for action in actions:
                if action[0] == "match":
                    results.append(card.match(action[1]))
                elif action[0] == "unmatched":
                    results.append(card.unmatched())
                elif action[0] == "reset":
                    card.reset()
            returned = tuple(results)

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Actions: {actions}")
            print(f"   Expected: {expected}")
            print(f"   Got:      {returned}")

    print(f"\nSCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()