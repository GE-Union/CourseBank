# experiment_numbers.py 
# CC-BY Louis Leblanc, 2025

def experiment_numbers(experiments):
    exp = {}
    for e in experiments:
        value = int(e.split('-')[1])
        if e[0] in exp.keys():
            if exp[e[0]] < value:
                exp[e[0]] = value
        else:
            exp[e[0]] = value
    return exp