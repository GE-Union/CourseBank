from new_price import new_price

tests = [
    (143.5, 40, (86.1, '86.10 DKK')),
    (125.5, 10, (112.95, '112.95 DKK')),
    (149.0, 5, (141.55, '141.55 DKK')),
    (199.0, 12, (175.12, '175.12 DKK')),
    (299.0, 25, (224.25, '224.25 DKK')),
    (400.0, 30, (280.0, '280.00 DKK')),
    (610.0, 40, (366.0, '366.00 DKK')),
    (750.0, 45, (412.5, '412.50 DKK')),
    (890.0, 50, (445.0, '445.00 DKK')),
    (19.0, 5, (18.05, '18.05 DKK')),
]


def test():
    SCORE = 0

    for i, (price, discount, expected) in enumerate(tests):
        result = new_price(price, discount)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    new_price({price}, {discount})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
