import math
from orbital_period import orbital_period

tests = [
    ((1.5 * 10**11, 2.0 * 10**30), 31593584.1373),
    ((1.0 * 10**11, 2.0 * 10**30), 17197368.95157193),
    ((1230000.0, 87600000000.0), 3544725590.7105),
    ((560000000.0, 540000000000.0), 13869543503820.715),
    ((1.0 * 10**10, 2.5 * 10**25), 153817944.0394365),
    ((2.5 * 10**8, 0.8 * 10**14), 339892847807.6825),
    ((8.5 * 10**15, 1.2 * 10**35), 1739861876631.025),
    ((6.0 * 10**5, 9.5 * 10**8), 11596904464.73603),
    ((3.4 * 10**7, 7.0 * 10**13), 18224111424.98193),
    ((0.7 * 10**8, 3.0 * 10**12), 260053940696.6384),
]

def test():
    SCORE = 0
    for i, (inputs, expected) in enumerate(tests):
        r, m = inputs
        result = orbital_period(r, m)
        print(f"Test {i+1}: ", end="")
        if math.isclose(result, expected):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    orbital_period({r}, {m})")
            print(f"    Expected {expected}, got {result}")

    print("")
    print(f"SCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()

