from modified_blackjack import modified_blackjack

tests = [
    ([5, 2, 3, 9, 7, 6, 2, 4], (1, 4)),
    ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11], (0, 6)),
    ([1, 2, 3, 9, 5, 6, 7, 8, 9, 10, 11], (5, 3)),
    ([1, 2, 3, 9, 5, 6, 11, 8, 9, 10, 11], (9, 2)),
    ([1, 2, 3, 9, 5, 6, 11, 8, 9, 10, 10], (-1, -1)),
    ([7, 2, 5, 11, 3, 4, 6, 1, 2, 5, 1, 7], (1, 4)),
    ([1] * 21, (0, 21)),
    ([5, 10, 10, 10, 5, 5, 10, 5, 5, 10, 5], (-1, -1)),
    ([5, 10, 10, 10, 5, 5, 10, 5, 5, 5, 5, 5, 10, 10, 11], (13, 2)),
    ([], (-1, -1)),
]


def test():
    SCORE = 0

    for i, (cards, expected) in enumerate(tests):
        result = modified_blackjack(cards)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    modified_blackjack({cards})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()