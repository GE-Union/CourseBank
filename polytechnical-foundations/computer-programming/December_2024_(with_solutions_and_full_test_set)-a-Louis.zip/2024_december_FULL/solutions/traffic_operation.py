# traffic_operation.py 
# CC-BY Louis Leblanc, 2025

def traffic_operation(hour):
    if 7 <= hour < 9 or 15 <= hour < 17:
        return 'rush hour'
    elif 22 <= hour < 24 or 0 <= hour < 6:
        return 'night'
    else:
        return 'normal'