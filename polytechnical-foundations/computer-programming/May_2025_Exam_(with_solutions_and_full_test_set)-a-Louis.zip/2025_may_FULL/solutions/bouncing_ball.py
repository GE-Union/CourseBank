# bouncing_ball.py 
# CC-BY Louis Leblanc, 2025

def bouncing_ball(h0):
    h = h0
    n = 0
    while h >= 1:
        h = 2*h/3
        n += 1
    return n