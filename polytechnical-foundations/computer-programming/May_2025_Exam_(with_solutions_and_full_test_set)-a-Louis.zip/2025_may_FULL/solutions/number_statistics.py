# number_statistics.py 
# CC-BY Louis Leblanc, 2025

def number_statistics(filename, number):
    list = []
    with open(filename, 'r') as f:
        for line in f.readlines():
            line = line.split()
            if line != []:
                list.append(line.count(str(number)))
    return list
