from bouncing_ball import bouncing_ball

tests = [
    (2.5, 3),
    (50.0, 10),
    (100.0, 12),
    (200.0, 14),
    (3000.0, 20),
    (7.252, 5),
    (1.0, 1),
    (0.5, 0),
    (10.0, 6),
    (17.0, 7)
]


def test():
    SCORE = 0

    for i, (input_val, expected) in enumerate(tests):
        result = bouncing_ball(input_val)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    bouncing_ball({input_val})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()