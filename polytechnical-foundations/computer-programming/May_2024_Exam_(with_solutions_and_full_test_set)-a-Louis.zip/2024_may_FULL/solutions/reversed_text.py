# reversed_text.py 
# CC-BY Louis Leblanc, 2025

def reversed_text(text, option):
    words = text.split()
    if option == "words":
        return ' '.join(reversed(words))
    else:
        return ' '.join([''.join(reversed([i for i in word])) for word in words])