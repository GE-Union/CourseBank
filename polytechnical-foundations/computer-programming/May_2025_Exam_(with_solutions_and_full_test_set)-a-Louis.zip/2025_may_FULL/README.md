# 2025 May Exam · Full Test Suite

---

This folder contains the **full** test suite for the *2025 May* exam in *Computer Programming*.

If your programs pass all the tests, **they should also pass on DTU Learn**.

## Disclaimer

The code files provided are meant for educational purposes only. 
While every effort has been made to ensure they are accurate, users are responsible for their own use. 
There’s no guarantee that the code will work as expected or be error-free.
What is more, the solutions provided in this folder may not be the most optimal.

## Copyright

This test suite was developed based on publicly available feedback data from DTU Learn. 
The test cases belong to their respective creators. 
The testing code was partially generated using LLMs. 
**For educational purposes only.**

The solutions are licensed under CC-BY, copyright Louis Leblanc.