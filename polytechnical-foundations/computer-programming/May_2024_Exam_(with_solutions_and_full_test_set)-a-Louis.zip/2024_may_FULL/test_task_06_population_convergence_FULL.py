from population_convergence import population_convergence

tests = [
    ((4.8, 0.65), 6),
    ((11.4, 0.45), 5),
    ((14.4, 0.5), 5),
    ((3.4, 0.2), 25),
    ((0.4, 0.8), 9),
    ((10.4, 0.1), 13),
    ((18.4, 0.05), 75),
    ((8.4, 0.05), 58),
    ((7.2, 0.01), 364),
    ((17.2, 0.01), 373),
]


def test():
    SCORE = 0
    for i, ((start, rate), expected) in enumerate(tests):
        returned = population_convergence(start, rate)

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   population_convergence({start}, {rate})\n    should return {expected}\n    but got {returned}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
