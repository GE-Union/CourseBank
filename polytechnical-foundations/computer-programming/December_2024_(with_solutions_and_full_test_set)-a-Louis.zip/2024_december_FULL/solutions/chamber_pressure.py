# chamber_pressure.py 
# CC-BY Louis Leblanc, 2025

def chamber_pressure(P, Pmax, Pcrit, k):
    hour = 0
    while P < Pcrit:
        P += k*(Pmax - P)
        hour += 1
    return hour