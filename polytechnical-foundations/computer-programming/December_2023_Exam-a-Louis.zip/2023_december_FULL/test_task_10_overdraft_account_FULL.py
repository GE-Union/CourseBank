from bank_account import OverdraftAccount

tests = [
    # Test 1
    (0, 500, [
        ('get_balance',),
        ('deposit', 1000),
        ('get_balance',),
        ('withdraw', 1300),
        ('get_balance',),
        ('withdraw', 500),
        ('get_balance',)
    ], (0, 1000, 1300, -300, 0, -300)),

    # Test 2
    (31, 200, [
        ('get_balance',)
    ], 31),

    # Test 3
    (3090, 300, [
        ('withdraw', 1100),
        ('get_balance',)
    ], (1100, 1990)),

    # Test 4
    (200, 500, [
        ('withdraw', 600),
        ('get_balance',)
    ], (600, -400)),

    # Test 5
    (200, 5000, [
        ('withdraw', 10000),
        ('get_balance',)
    ], (0, 200)),

    # Test 6
    (0, 2000, [
        ('withdraw', 2000),
        ('get_balance',)
    ], (2000, -2000)),

    # Test 7
    (0, 0, [
        ('deposit', 1234),
        ('get_balance',)
    ], 1234),

    # Test 8
    (1000, 500, [
        ('get_balance',),
        ('deposit', 200),
        ('get_balance',),
        ('withdraw', 800),
        ('get_balance',),
        ('withdraw', 901),
        ('get_balance',)
    ], (1000, 1200, 800, 400, 0, 400)),

    # Test 9
    (403, 200, [
        ('withdraw', 550),
        ('get_balance',),
        ('withdraw', 403),
        ('get_balance',)
    ], (550, -147, 0, -147)),

    # Test 10
    (150, 200, [
        ('get_balance',),
        ('withdraw', 20000),
        ('get_balance',),
        ('withdraw', 30),
        ('get_balance',)
    ], (150, 0, 150, 30, 120)),
]


def test():
    SCORE = 0
    for i, (initial_balance, overdraft_limit, actions, expected) in enumerate(tests, 1):
        account = OverdraftAccount(initial_balance, overdraft_limit)
        results = []

        for action in actions:
            if action[0] == 'deposit':
                account.deposit(action[1])
            elif action[0] == 'withdraw':
                results.append(account.withdraw(action[1]))
            elif action[0] == 'get_balance':
                results.append(account.get_balance())
        results = tuple(results)

        # If the expected output is a single value, unwrap results
        if isinstance(expected, int):
            results = results[-1]

        print(f"Test {i}: ", end="")
        if results == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   OverdraftAccount({initial_balance}, {overdraft_limit}) with actions {actions}\n    should return {repr(expected)},\n    but got {repr(results)}")

    print(f"\nSCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()