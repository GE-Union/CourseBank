from bank_account import BankAccount

tests = [
    # Test 1
    (1000, [
        ('get_balance',),
        ('deposit', 500),
        ('get_balance',),
        ('withdraw', 200),
        ('get_balance',),
        ('withdraw', 2000),
        ('get_balance',)
    ], (1000, 1500, 200, 1300, 0, 1300)),

    # Test 2
    (35, [
        ('get_balance',)
    ], 35),

    # Test 3
    (3090, [
        ('withdraw', 90),
        ('get_balance',)
    ], (90, 3000)),

    # Test 4
    (403, [
        ('withdraw', 550),
        ('get_balance',)
    ], (0, 403)),

    # Test 5
    (0, [
        ('get_balance',)
    ], 0),

    # Test 6
    (0, [
        ('deposit', 100),
        ('get_balance',)
    ], 100),

    # Test 7
    (550, [
        ('get_balance',),
        ('deposit', 450),
        ('get_balance',),
        ('withdraw', 200),
        ('get_balance',),
        ('withdraw', 2000),
        ('get_balance',)
    ], (550, 1000, 200, 800, 0, 800)),

    # Test 8
    (1000, [
        ('get_balance',),
        ('deposit', 500),
        ('get_balance',),
        ('withdraw', 200),
        ('get_balance',),
        ('withdraw', 2000),
        ('get_balance',)
    ], (1000, 1500, 200, 1300, 0, 1300)),

    # Test 9
    (1000, [
        ('get_balance',)
    ], 1000),

    # Test 10
    (1000, [
        ('withdraw', 4000),
        ('withdraw', 400),
        ('get_balance',)
    ], (0, 400, 600)),
]


def test():
    SCORE = 0
    for i, (initial_balance, actions, expected) in enumerate(tests, 1):
        account = BankAccount(initial_balance)
        results = []

        for action in actions:
            if action[0] == 'deposit':
                account.deposit(action[1])
            elif action[0] == 'withdraw':
                results.append(account.withdraw(action[1]))
            elif action[0] == 'get_balance':
                results.append(account.get_balance())
        results = tuple(results)

        # If the expected output is a single value, unwrap results
        if isinstance(expected, int):
            results = results[-1]

        print(f"Test {i}: ", end="")
        if results == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   BankAccount({initial_balance}) with actions {actions}\n    should return {repr(expected)},\n    but got {repr(results)}")

    print(f"\nSCORE: [{SCORE}/10]")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()