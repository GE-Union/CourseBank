# new_price.py 
# CC-BY Louis Leblanc, 2025

def new_price(price, discount):
    new_price = price - price*discount/100
    return (new_price, f"{new_price:.2f} DKK")