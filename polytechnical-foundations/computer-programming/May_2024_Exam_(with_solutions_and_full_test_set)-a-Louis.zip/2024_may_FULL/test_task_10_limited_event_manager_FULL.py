from event_manager import LimitedEventManager

tests = [
    # Test 1
    (3, [('register', 'Mike'), ('register', 'Emily'), ('register', 'Sara'), ('register', 'Peter'), ('get_num_registrations', None)], 
     (True, True, True, False, 3)),
    # Test 2
    (2, [('register', 'Mike'), ('register', 'Emily'), ('register', 'Sara'), ('deregister', 'Mike'), 
         ('register', 'Peter'), ('register', 'Mike'), ('get_num_registrations', None)],
     (True, True, False, True, True, False, 2)),
    # Test 3
    (0, [('get_num_registrations', None), ('register', 'Mike'), ('deregister', 'Mike'), 
         ('deregister', 'Mike'), ('get_num_registrations', None)],
     (0, False, False, False, 0)),
    # Test 4
    (2, [('register', 'Bjarke'), ('register', 'Lars'), ('register', 'Mike'), ('register', 'Mike'),
         ('deregister', 'Bjarke'), ('register', 'Mike'), ('register', 'Bjarke'), ('get_num_registrations', None)],
     (True, True, False, False, True, True, False, 2)),
    # Test 5
    (3, [('deregister', 'NonExistentUser'), ('register', 'Mike'), ('register', 'Mike'),
         ('register', 'Sara'), ('register', 'Peter'), ('get_num_registrations', None)],
     (False, True, False, True, True, 3)),
    # Test 6
    (2, [('register', 'Mike'), ('register', 'Emily'), ('register', 'Emily'), ('deregister', 'Mike'),
         ('register', 'Sara'), ('register', 'Peter'), ('register', 'Mike'), ('get_num_registrations', None)],
     (True, True, False, True, True, False, False, 2)),
    # Test 7
    (5, [('get_num_registrations', None), ('register', 'Lars'), ('register', 'Mette'), ('register', 'Marianne'),
         ('register', 'Pernille'), ('register', 'Niels'), ('register', 'Klaus'), ('deregister', 'Lars'),
         ('get_num_registrations', None)],
     (0, True, True, True, True, True, False, True, 4)),
    # Test 8
    (1, [('get_num_registrations', None), ('register', 'Brutus'), ('register', 'Brutus'), ('register', 'Bronkitis'),
         ('deregister', 'Brutus'), ('get_num_registrations', None)],
     (0, True, False, False, True, 0)),
    # Test 9
    (2, [('get_num_registrations', None), ('register', 'Bruno'), ('register', 'Bruno'), ('register', 'Emilie'),
         ('register', 'SazaDaSuzzy'), ('deregister', 'Bruno'), ('register', 'Peter'), ('register', 'Bruno'),
         ('get_num_registrations', None)],
     (0, True, False, True, False, True, True, False, 2)),
    # Test 10
    (100, [('get_num_registrations', None), ('register', 'Timian'), ('deregister', 'Timian'), ('get_num_registrations', None)],
     (0, True, True, 0)),
]


def test():
    SCORE = 0
    for i, (limit, actions, expected) in enumerate(tests):
        manager = LimitedEventManager(limit)
        results = []
        for action, name in actions:
            if action == 'register':
                results.append(manager.register(name))
            elif action == 'deregister':
                results.append(manager.deregister(name))
            elif action == 'get_num_registrations':
                results.append(manager.get_num_registrations())
        print(f"Test {i+1}: ", end="")
        if tuple(results) == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Expected: {expected}\n   Got: {tuple(results)}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
