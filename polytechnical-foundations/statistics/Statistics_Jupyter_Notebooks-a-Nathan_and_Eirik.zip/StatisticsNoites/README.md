<h3 align="center">A collection of Jupyter notebooks for DTU Statistics</h3>

## Prerequisites
### VENV:
If you use *Conda*, use the following command:  
```conda create -n Statistics python=3.12.9 numpy matplotlib pandas scipy```

Otherwise, make sure your environment has `python 3.12.9` and packages `numpy`, `matplotlib`, `pandas`, `scipy`
## The Good Stuff
The repo contains a handful of individual notebooks, each for a particular topic.  
**!!! Each time you open a notebook, run the 'Init Script' and everything else in the notebook will work. !!!**