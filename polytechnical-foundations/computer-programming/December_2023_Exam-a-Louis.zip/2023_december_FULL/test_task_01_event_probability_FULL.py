import math

from event_probability import event_probability

arguments = [
    (100, 25), (100, 100), (100, 0), (100, 50), (500, 75), (200, 25), (50, 5000), (120, 2000), (1000, 5000), (25, 5)
]
expected = [
    0.22217864060085335,
    0.6339676587267709,
    0.0,
    0.39499393286246365,
    0.13942129246327162,
    0.11777975705119881,
    1.0,
    0.9999999461196151,
    0.9932788880401344,
    0.18462730240000014
]


def test():
    SCORE = 0
    for i in range(len(arguments)): 
        exp = expected[i]
        res = event_probability(*arguments[i])
        print(f"Test {i+1}: ", end="")
        if math.isclose(exp, res):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   event_probability({arguments[i][0]},{arguments[i][1]}) should return {exp}, but got {res}")

    print("")    

    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")
    
    return SCORE,len(arguments)

if __name__ == '__main__':
    test()