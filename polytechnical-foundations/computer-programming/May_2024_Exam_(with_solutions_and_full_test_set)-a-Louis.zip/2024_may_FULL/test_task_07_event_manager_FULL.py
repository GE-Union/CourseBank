from event_manager import EventManager

tests = [
    # Test 1
    (
        [('get',), ('deregister', 'Mike'), ('register', 'Mike'), ('register', 'Mike'),
         ('register', 'John'), ('deregister', 'Mike'), ('get',)],
        (0, False, True, False, True, True, 1)
    ),
    # Test 2
    (
        [('register', 'Bjarke'), ('register', 'Bjarke'), ('deregister', 'Bjarke'), ('get',)],
        (True, False, True, 0)
    ),
    # Test 3
    (
        [('deregister', 'Mike'), ('get',)],
        (False, 0)
    ),
    # Test 4
    (
        [('register', 'Mike'), ('register', 'Emily'), ('register', 'Emily'), ('register', 'Sara'),
         ('register', 'Peter'), ('register', 'John'), ('deregister', 'Mike'), ('deregister', 'Mike'),
         ('get',)],
        (True, True, False, True, True, True, True, False, 4)
    ),
    # Test 5
    (
        [('register', 'Mike'), ('register', 'Emily'), ('register', 'Sara'), ('register', 'Peter'),
         ('register', 'John'), ('register', 'John'), ('deregister', 'Mike'), ('deregister', 'Emily'),
         ('deregister', 'Sara'), ('deregister', 'Peter'), ('deregister', 'John'), ('get',)],
        (True, True, True, True, True, False, True, True, True, True, True, 0)
    ),
    # Test 6
    (
        [('deregister', 'Lykke'), ('register', 'Mike'), ('register', 'Orla'), ('deregister', 'Mike'),
         ('register', 'Mike'), ('register', 'Lykke'), ('get',)],
        (False, True, True, True, True, True, 3)
    ),
    # Test 7
    (
        [('register', 'Mike'), ('register', 'Emily'), ('register', 'Sara'), ('register', 'Peter'),
         ('register', 'John'), ('deregister', 'Mike'), ('deregister', 'Mike'), ('register', 'Sara'),
         ('deregister', 'Emily'), ('get',)],
        (True, True, True, True, True, True, False, False, True, 3)
    ),
    # Test 8
    (
        [('register', 'Diana'), ('register', 'Eve'), ('register', 'Frank'), ('deregister', 'Diana'),
         ('deregister', 'Eve'), ('deregister', 'Frank'), ('deregister', 'Frank'), ('get',)],
        (True, True, True, True, True, True, False, 0)
    ),
    # Test 9
    (
        [('register', 'Ian'), ('register', 'Jane'), ('deregister', 'Ian'), ('register', 'Ian'),
         ('register', 'Kim'), ('deregister', 'Jane')],
        (True, True, True, True, True, True)
    ),
    # Test 10
    (
        [('get',)],
        0
    ),
]


def test():
    SCORE = 0
    for i, (actions, expected) in enumerate(tests):
        em = EventManager()
        results = []
        for action in actions:
            if action[0] == 'register':
                results.append(em.register(action[1]))
            elif action[0] == 'deregister':
                results.append(em.deregister(action[1]))
            elif action[0] == 'get':
                results.append(em.get_num_registrations())
        returned = tuple(results) if len(results) > 1 else results[0]

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Actions: {actions}\n    should return {expected}\n    but got {returned}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
