from collatz_conjecture import collatz_conjecture

tests = [
    (3, 7),
    (9, 19),
    (12, 9),
    (1, 0),
    (5, 5),
    (17, 12),
    (32, 5),
    (11, 14),
    (27, 111),
    (1600, 29),
]


def test():
    SCORE = 0
    for i in range(len(tests)):
        returned = collatz_conjecture(tests[i][0])
        expected = tests[i][1]

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   collatz_conjecture({tests[i][0]})\n    should return {expected}\n    but got {returned}")

    print("")    
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()