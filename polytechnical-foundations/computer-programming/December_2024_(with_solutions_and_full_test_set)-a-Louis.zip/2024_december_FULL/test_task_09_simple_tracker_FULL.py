from simple_tracker import SimpleTracker

tests = [
    # Test 1
    (
        500,
        [('add', 510), ('add', 200), ('add', 352), ('stats',), ('reset',), ('stats',)],
        (False, True, True, (552, 152), (0, 0))
    ),
    # Test 2
    (
        600,
        [('add', 500), ('add', 60), ('add', 800)],
        (True, True, False)
    ),
    # Test 3
    (
        50,
        [('add', 11), ('add', 32), ('add', 17), ('stats',)],
        (True, True, True, (60, 21))
    ),
    # Test 4
    (
        110,
        [('add', 50), ('stats',), ('reset',), ('add', 60), ('stats',)],
        (True, (50, 0), True, (60, 0))
    ),
    # Test 5
    (
        1020,
        [('add', 1050), ('add', -50), ('add', 823)],
        (False, False, True)
    ),
    # Test 6
    (
        250,
        [('add', 10), ('add', 10), ('add', 10), ('stats',)],
        (True, True, True, (30, 0))
    ),
    # Test 7
    (
        100,
        [('add', 90), ('add', 0), ('stats',)],
        (True, False, (90, 0))
    ),
    # Test 8
    (
        150,
        [('add', 90), ('reset',), ('add', 10), ('add', 150), ('stats',)],
        (True, True, True, (160, 140))
    ),
    # Test 9
    (
        500,
        [('add', 50), ('add', 100), ('add', 150), ('add', 200), ('add', 250),
         ('add', 300), ('add', 350), ('add', 400), ('add', 450), ('stats',)],
        (True, True, True, True, True, True, True, True, True, (2250, 400))
    ),
    # Test 10
    (
        813,
        [('add', 510), ('add', 1200), ('add', 390), ('stats',),
         ('reset',), ('add', 283), ('add', 798), ('add', 340), ('stats',)],
        (True, False, True, (900, 120), True, True, True, (1421, 515))
    ),
]


def test():
    SCORE = 0
    for i, (init, actions, expected) in enumerate(tests):
        tracker = SimpleTracker(init)  # default limit, will override if necessary
        results = []

        for action in actions:
            if action[0] == 'add':
                results.append(tracker.add(action[1]))
            elif action[0] == 'stats':
                results.append(tracker.stats())
            elif action[0] == 'reset':
                tracker.reset()

        returned = tuple(results) if len(results) > 1 else results[0]

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   Tracker limit: {init}\n   Actions: {actions}\n   should return {expected}\n   but got {returned}")

    print("")
    print(f"SCORE: [{SCORE}/{len(tests)}] ")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
