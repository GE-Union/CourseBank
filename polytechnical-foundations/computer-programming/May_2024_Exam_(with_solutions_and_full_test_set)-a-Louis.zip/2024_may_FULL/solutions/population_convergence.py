# population_convergence.py 
# CC-BY Louis Leblanc, 2025

def population_convergence(N, r):
    year = 0
    while N < 10-10*0.01 or 10+10*0.01 < N:
        N = N + r*(1 - N/10)*N
        year += 1
    return year