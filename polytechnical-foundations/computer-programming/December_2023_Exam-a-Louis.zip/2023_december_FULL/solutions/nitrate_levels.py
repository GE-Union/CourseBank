# nitrate_levels.py 
# CC-BY Louis Leblanc, 2025

def nitrate_levels(filename):
    levels = [0]*5
    with open(filename, 'r') as f:
        for line in f.readlines():
            value = float(line)
            if value <= 4.0:
                levels[0] += 1
            elif value <= 9.0:
                levels[1] += 1
            elif value < 40.0:
                levels[2] += 1
            elif value < 50.0:
                levels[3] += 1
            else: 
                levels[4] += 1
    return tuple(levels)
        