import os

from nitrate_levels import nitrate_levels

tests = [
    ("files/nitrate_data_A.txt", (0, 0, 8, 2, 0)),
    ("files/nitrate_data_B.txt", (0, 0, 21, 16, 5)),
    ("files/nitrate_data_C.txt", (0, 0, 8, 2, 0)),
    ("files/nitrate_data_D.txt", (6, 6, 17, 0, 0)),
    ("files/nitrate_data_E.txt", (0, 0, 0, 5, 22)),
    ("files/nitrate_data_F.txt", (5, 5, 9, 0, 0)),
    ("files/nitrate_data_G.txt", (0, 0, 43, 0, 0)),
    ("files/nitrate_data_H.txt", (9, 7, 15, 0, 0)),
    ("files/nitrate_data_I.txt", (0, 0, 14, 21, 8)),
    ("files/nitrate_data_J.txt", (0, 1, 24, 7, 0)),
]

for (path,_) in tests:
    if not os.path.isfile(path):
        print(f"Test for task 9 failed because path \"{path}\" could not be found.")
        print('This does not indicate anything about the correctness of your code.')
        print('Please open the correct directory in VSCode (as described under `Solving Exam Tasks` in the pdf), or modify the path above.')
        exit(1)



def test():
    SCORE = 0
    for i, (filepath, expected) in enumerate(tests):
        result = nitrate_levels(filepath)
        print(f"Test {i+1}: ", end="")
        if result == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    nitrate_levels('{filepath}')")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == '__main__':
    test()