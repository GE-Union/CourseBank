# count_differences.py 
# CC-BY Louis Leblanc, 2025

def count_differences(filename1, filename2):
    differences = 0
    with open(filename1, 'r') as a, open(filename2, 'r') as b:
        data_A = list(map(lambda x: int(x), a.readline().split(",")))
        data_B = list(map(lambda x: int(x), b.readline().split(",")))
        if len(data_A) != len(data_B):
            return -1
        for i in range(len(data_A)):
            if data_A[i] != data_B[i]:
                differences += 1 
    return differences