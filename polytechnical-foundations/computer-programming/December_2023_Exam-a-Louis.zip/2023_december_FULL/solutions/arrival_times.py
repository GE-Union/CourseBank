# arrival_times.py 
# CC-BY Louis Leblanc, 2025

def arrival_times(schedule, delay):
    new_schedule = []
    for time in schedule:
        hours, minutes = [int(i) for i in time.split(":")]
        minutes += delay
        while minutes >= 60:
            minutes -= 60
            hours += 1
            if hours == 24:
                hours = 0
        new_schedule.append(str(hours).zfill(2)+":"+str(minutes).zfill(2))
    return new_schedule