import numpy as np
from weighted_average import weighted_average

tests = [
    (np.array([4.8, 6.6, 12.2, 7.3, 6.5]), 6.748513328262832),
    (np.array([1., 2., 3., 4., 5.]), 3.0),
    (np.array([100089., 137464.8, 17654., 183454., 16933., 343848.]), 113744.0065265217),
    (np.array([1, 1, 1, 1, 10, 8.9]), 2.612403513992105),
    (np.array([0, 0, 4, 6, -5.9, 98]), 2.810364117563556),
    (np.array([123.6, 12456.2, -98881.2, 28273.7, 1000.09]), 4469.970517823297),
    (np.array([1.18, 1.18]), 1.18),
    (np.array([5.7, 9.6, 4.5, 2.6, 2.5, -0.6, -9.3, -4, 0, 8.6, 9.5]), 3.222768149667421),
    (np.array([7.8, 6.6, 12.2, 7.3, 6.5, -96.8]), 6.145046653498477),
    (np.array([1.9, 1.9, 1.9, 1.9, 1000, 76, 864]), 131.315713899977),
]


def test():
    SCORE = 0

    for i, (inputs, expected) in enumerate(tests):
        result = weighted_average(inputs)
        print(f"Test {i+1}: ", end="")
        if np.isclose(result, expected, rtol=1e-9):
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"    weighted_average({inputs})")
            print(f"    Expected {expected}, got {result}")

    print(f"\nSCORE: [{SCORE}/{len(tests)}]")
    if SCORE == len(tests):
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
