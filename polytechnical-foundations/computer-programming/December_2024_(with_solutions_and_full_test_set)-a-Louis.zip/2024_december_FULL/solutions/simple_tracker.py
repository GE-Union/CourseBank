# simple_tracker.py 
# CC-BY Louis Leblanc, 2025

class SimpleTracker:
    def __init__(self, limit): 
        self.limit = limit
        self.numbers = []
    def add(self, number):
        if 0 < number <= self.limit:
            self.numbers.append(number)
            return True
        return False
    def reset(self):
        self.numbers = []
    def stats(self):
        if len(self.numbers):
            return (sum(self.numbers), max(self.numbers)-min(self.numbers))
        else:
            return (0,0)

class AdvancedTracker(SimpleTracker):
    def __init__(self, limit, max_delta):
        super().__init__(limit)
        self.max_delta = max_delta
    def add(self, number):
        if 0 < number <= self.limit:
            if len(self.numbers):
                if abs(self.numbers[-1] - number) > self.max_delta:
                    return False
            self.numbers.append(number)
            return True
        return False