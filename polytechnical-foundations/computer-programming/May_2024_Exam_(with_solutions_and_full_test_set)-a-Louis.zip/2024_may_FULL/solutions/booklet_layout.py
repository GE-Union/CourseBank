# booklet_layout.py 
# CC-BY Louis Leblanc, 2025

def booklet_layout(content_pages):
    return (content_pages + (4 - content_pages%4)%4, (4 - content_pages%4)%4)