from reversed_text import reversed_text

tests = [
    ('Hello world we are going to do some programming', 'letters',
     'olleH dlrow ew era gniog ot od emos gnimmargorp'),
    ('Hello world we are going to do some programming', 'words',
     'programming some do to going are we world Hello'),
    ('This is a sentence with words separated by spaces', 'letters',
     'sihT si a ecnetnes htiw sdrow detarapes yb secaps'),
    ('This is a sentence with words separated by spaces', 'words',
     'spaces by separated words with sentence a is This'),
    ('Det er ikke vigtigt om det er Dansk eller Engelsk', 'letters',
     'teD re ekki tgitgiv mo ted re ksnaD relle kslegnE'),
    ('Det er ikke vigtigt om det er Dansk eller Engelsk', 'words',
     'Engelsk eller Dansk er det om vigtigt ikke er Det'),
    ('Yet another sentence to be reversed in two different ways', 'letters',
     'teY rehtona ecnetnes ot eb desrever ni owt tnereffid syaw'),
    ('Yet another sentence to be reversed in two different ways', 'words',
     'ways different two in reversed be to sentence another Yet'),
    ('Nip sip sup i mekke tekke tup', 'letters',
     'piN pis pus i ekkem ekket put'),
    ('Nip sip sup i mekke tekke tup', 'words',
     'tup tekke mekke i sup sip Nip')
]


def test():
    SCORE = 0
    for i, (text, mode, expected) in enumerate(tests):
        returned = reversed_text(text, mode)

        print(f"Test {i+1}: ", end="")
        if returned == expected:
            print("Passed")
            SCORE += 1
        else:
            print("Failed")
            print(f"   reversed_text({repr(text)}, {repr(mode)})\n    should return {repr(expected)}\n    but got {repr(returned)}")

    print("")
    print(f"SCORE: [{SCORE}/10] ")
    if SCORE == 10:
        print("ALL TESTS PASSED! CONGRATS!")
    else:
        print("Some tests failed, please check your code again.")

    return SCORE, len(tests)


if __name__ == "__main__":
    test()
