# fruit_weights.py 
# CC-BY Louis Leblanc, 2025

from math import floor

def fruit_weights(table):
    fruits = {}
    for f in table.keys():
        if f.lower() in fruits.keys():
            fruits[f.lower()].append(table[f])
        else:
            fruits[f.lower()] = [table[f]]

    for f in fruits:
        fruits[f] = floor(sum(fruits[f])/len(fruits[f]))

    return fruits