# bank_account.py 
# CC-BY Louis Leblanc, 2025

class BankAccount():
    def __init__(self, balance):
        if balance < 0:
            raise ValueError("Cannot initialize account with a negative amount of money")
        self.balance = balance

    def deposit(self, amount):
        if amount < 0:
            raise ValueError("Cannot deposit a negative amount of money")
        self.balance += amount

    def withdraw(self, amount):
        if amount < 0:
            raise ValueError("Cannot withdraw a negative amount of money")
        if self.balance - amount >= 0:
            self.balance -= amount 
            return amount 
        return 0 

    def get_balance(self):
        return self.balance



class OverdraftAccount(BankAccount):
    def __init__(self, balance, overdraft_limit):
        super().__init__(balance)
        self.overdraft_limit = overdraft_limit

    def withdraw(self, amount):
        if amount <= self.balance + self.overdraft_limit:
            self.balance -= amount
            return amount
        else:
            return 0